from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from config import config
from services.models.models import Role, RoleTabPermission, Permission, Languages, Region, SubscriptionType, TimeZone, Tab, Nano
# Create SQLAlchemy engine
engine = create_engine(config.Config.SQLALCHEMY_DATABASE_URI)

# Create a session maker
Session = sessionmaker(bind=engine)

# Create a declarative base
Base = declarative_base()

# Create tables in the database
Base.metadata.create_all(engine)

# Create a session
session = Session()

# Insert default data into Role tables
role_data = [
    {
        'rolename': 'Owner',
        'description': 'Create Projects, Manage Users and Workflows'
    },
    {
        'rolename': 'Admin',
        'description': 'Full Access to the System'
    },
    {
        'rolename': 'Manager',
        'description': 'Create Projects, Manage Users and Workflows'
    },
    {
        'rolename': 'User',
        'description': 'Standard User Access, Create Tasks and Workflows'
    }
]

# Insert default data into Language tables
language_data = [
    {
        'language': 'English'
    }
]

# Insert default data into Region tables
region_data = [
    {
        'region': 'US'
    },
    {
        'region': 'EU'
    },
    {
        'region': 'IN'
    }
]

# Insert default data into Permission tables
permission_data = [
    {
        'permissionname': 'RW',
        'description':'Read Only'
    },
    {
        'permissionname': 'RO',
        'description':'Read Write'
    }
]

# Insert default data into Subscription tables
subscription_data = [
    {
        "typename": "Free",
        "maxworkflows": "5",
        "maxprojects": "1",
        "maxusers": "2",
        "maxtasks": "10"
    },
    {
        "typename": "Small",
        "maxworkflows": "10",
        "maxprojects": "3",
        "maxusers": "5",
        "maxtasks": "25"
    },
    {
        "typename": "Medium",
        "maxworkflows": "25",
        "maxprojects": "5",
        "maxusers": "10",
        "maxtasks": "50"
    },
    {
        "typename": "Large",
        "maxworkflows": "50",
        "maxprojects": "10",
        "maxusers": "25",
        "maxtasks": "100"
    }
]

# Insert default data into Tab tables
tab_data = [
    {
        "tabname": "INVENTORY_CREDENTIALS",
        "description": "Credentials Store"
    },
    {
        "tabname": "INVENTORY_MACHINE",
        "description": "Machine Inventory"
    },
    {
        "tabname": "INVENTORY_GROUPS",
        "description": "Machine Groups"
    },
    {
        "tabname": "DASHBOARD",
        "description": "Home Dashboard for the User"
    },
    {
        "tabname": "WORKFLOW_CATALOG",
        "description": "Workflow Catalog"
    },
    {
        "tabname": "WORKFLOW_DESIGN",
        "description": "Workflow Design"
    },
    {
        "tabname": "WORKFLOW_APPROVALS",
        "description": "Workflow Approvals"
    },
    {
        "tabname": "WORKFLOW_HISTORY",
        "description": "Workflow History"
    },
    {
        "tabname": "REPORTS",
        "description": "Workflow Reports"
    },
    {
        "tabname": "ADMIN_USERS",
        "description": "Admin Users"
    },
    {
        "tabname": "ADMIN_ROLES",
        "description": "Admin Roles"
    },
    {
        "tabname": "ADMIN_PROJECTS",
        "description": "Admin Projects"
    },
    {
        "tabname": "ADMIN_TASKS",
        "description": "Global Task Repository"
    },
    {
        "tabname": "ADMIN_ENGINE",
        "description": "Admin Engine Configuration"
    },
    {
        "tabname": "ADMIN_BILLING",
        "description": "Admin Billing Information"
    }
]

# Insert default data into Role Tab Permission tables
roletabpermission_data = [
    {
        "roleid": "2",
        "tabid": "1",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "2",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "3",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "4",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "5",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "6",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "7",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "8",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "9",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "10",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "11",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "12",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "13",
        "permissionid": "1"
    },
    {
        "roleid": "2",
        "tabid": "14",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "4",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "5",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "6",
        "permissionid": "2"
    },
    {
        "roleid": "3",
        "tabid": "7",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "8",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "9",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "10",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "11",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "12",
        "permissionid": "1"
    },
    {
        "roleid": "3",
        "tabid": "13",
        "permissionid": "2"
    },
    {
        "roleid": "3",
        "tabid": "14",
        "permissionid": "2"
    },
    {
        "roleid": "4",
        "tabid": "1",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "2",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "3",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "4",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "5",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "6",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "7",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "8",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "9",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "13",
        "permissionid": "1"
    },
    {
        "roleid": "4",
        "tabid": "14",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "1",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "2",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "3",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "4",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "5",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "6",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "7",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "8",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "9",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "10",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "11",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "12",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "13",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "14",
        "permissionid": "1"
    },
    {
        "roleid": "1",
        "tabid": "15",
        "permissionid": "1"
    }
]

# Insert default data into Time Zone tables
timezone_data = [
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Melbourne",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AF",
        "countryname": "Afghanistan",
        "timezone": "Asia/Kabul",
        "gmtoffset": "UTC 2:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Toronto",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ID",
        "countryname": "Indonesia",
        "timezone": "Asia/Jakarta",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NZ",
        "countryname": "New Zealand",
        "timezone": "Pacific/Auckland",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SG",
        "countryname": "Singapore",
        "timezone": "Asia/Singapore",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ZA",
        "countryname": "South Africa",
        "timezone": "Africa/Johannesburg",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "UK",
        "countryname": "London",
        "timezone": "Europe/London",
        "gmtoffset": "UTC +00:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AX",
        "countryname": "Aland Islands",
        "timezone": "Europe/Mariehamn",
        "gmtoffset": "UTC 5:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AL",
        "countryname": "Albania",
        "timezone": "Europe/Tirane",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Palmer",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DZ",
        "countryname": "Algeria",
        "timezone": "Africa/Algiers",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AD",
        "countryname": "Andorra",
        "timezone": "Europe/Andorra",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AO",
        "countryname": "Angola",
        "timezone": "Africa/Luanda",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AI",
        "countryname": "Anguilla",
        "timezone": "America/Anguilla",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Casey",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Davis",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/DumontDUrville",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Mawson",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/McMurdo",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Rothera",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Syowa",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Troll",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AQ",
        "countryname": "Antarctica",
        "timezone": "Antarctica/Vostok",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AG",
        "countryname": "Antigua and Barbuda",
        "timezone": "America/Antigua",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Buenos_Aires",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Catamarca",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Cordoba",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Jujuy",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/La_Rioja",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Mendoza",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Rio_Gallegos",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Salta",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/San_Juan",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/San_Luis",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Tucuman",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AR",
        "countryname": "Argentina",
        "timezone": "America/Argentina/Ushuaia",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AM",
        "countryname": "Armenia",
        "timezone": "Asia/Yerevan",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AW",
        "countryname": "Aruba",
        "timezone": "America/Aruba",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Antarctica/Macquarie",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Adelaide",
        "gmtoffset": "UTC +09:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CG",
        "countryname": "Republic of the Congo",
        "timezone": "Africa/Brazzaville",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Brisbane",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Broken_Hill",
        "gmtoffset": "UTC +09:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Currie",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Darwin",
        "gmtoffset": "UTC +09:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Eucla",
        "gmtoffset": "UTC +08:45",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Hobart",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Lindeman",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Lord_Howe",
        "gmtoffset": "UTC +10:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Perth",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AU",
        "countryname": "Australia",
        "timezone": "Australia/Sydney",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AT",
        "countryname": "Austria",
        "timezone": "Europe/Vienna",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AZ",
        "countryname": "Azerbaijan",
        "timezone": "Asia/Baku",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BS",
        "countryname": "Bahamas",
        "timezone": "America/Nassau",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BH",
        "countryname": "Bahrain",
        "timezone": "Asia/Bahrain",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BD",
        "countryname": "Bangladesh",
        "timezone": "Asia/Dhaka",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BB",
        "countryname": "Barbados",
        "timezone": "America/Barbados",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BY",
        "countryname": "Belarus",
        "timezone": "Europe/Minsk",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BE",
        "countryname": "Belgium",
        "timezone": "Europe/Brussels",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BZ",
        "countryname": "Belize",
        "timezone": "America/Belize",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BJ",
        "countryname": "Benin",
        "timezone": "Africa/Porto-Novo",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BM",
        "countryname": "Bermuda",
        "timezone": "Atlantic/Bermuda",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BT",
        "countryname": "Bhutan",
        "timezone": "Asia/Thimphu",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BO",
        "countryname": "Bolivia",
        "timezone": "America/La_Paz",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BQ",
        "countryname": "Bonaire, Saint Eustatius and Saba",
        "timezone": "America/Kralendijk",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BA",
        "countryname": "Bosnia and Herzegovina",
        "timezone": "Europe/Sarajevo",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BW",
        "countryname": "Botswana",
        "timezone": "Africa/Gaborone",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Araguaina",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Bahia",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Belem",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Boa_Vista",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Campo_Grande",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Cuiaba",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Eirunepe",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Fortaleza",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Maceio",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Manaus",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Noronha",
        "gmtoffset": "UTC -02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Porto_Velho",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Recife",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Rio_Branco",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Santarem",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BR",
        "countryname": "Brazil",
        "timezone": "America/Sao_Paulo",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IO",
        "countryname": "British Indian Ocean Territory",
        "timezone": "Indian/Chagos",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "VG",
        "countryname": "British Virgin Islands",
        "timezone": "America/Tortola",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BN",
        "countryname": "Brunei",
        "timezone": "Asia/Brunei",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BG",
        "countryname": "Bulgaria",
        "timezone": "Europe/Sofia",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BF",
        "countryname": "Burkina Faso",
        "timezone": "Africa/Ouagadougou",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BI",
        "countryname": "Burundi",
        "timezone": "Africa/Bujumbura",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KH",
        "countryname": "Cambodia",
        "timezone": "Asia/Phnom_Penh",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CM",
        "countryname": "Cameroon",
        "timezone": "Africa/Douala",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Atikokan",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Blanc-Sablon",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Cambridge_Bay",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Creston",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Dawson",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Dawson_Creek",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Edmonton",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Fort_Nelson",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Glace_Bay",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Goose_Bay",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Halifax",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Inuvik",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Iqaluit",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Moncton",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Nipigon",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Pangnirtung",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Rainy_River",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Rankin_Inlet",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Regina",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Resolute",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/St_Johns",
        "gmtoffset": "UTC -02:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Swift_Current",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Thunder_Bay",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Vancouver",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Whitehorse",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Winnipeg",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CA",
        "countryname": "Canada",
        "timezone": "America/Yellowknife",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CV",
        "countryname": "Cape Verde",
        "timezone": "Atlantic/Cape_Verde",
        "gmtoffset": "UTC -01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KY",
        "countryname": "Cayman Islands",
        "timezone": "America/Cayman",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CF",
        "countryname": "Central African Republic",
        "timezone": "Africa/Bangui",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "TD",
        "countryname": "Chad",
        "timezone": "Africa/Ndjamena",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CL",
        "countryname": "Chile",
        "timezone": "America/Punta_Arenas",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CL",
        "countryname": "Chile",
        "timezone": "America/Santiago",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CL",
        "countryname": "Chile",
        "timezone": "Pacific/Easter",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CN",
        "countryname": "China",
        "timezone": "Asia/Shanghai",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CN",
        "countryname": "China",
        "timezone": "Asia/Urumqi",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CX",
        "countryname": "Christmas Island",
        "timezone": "Indian/Christmas",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CC",
        "countryname": "Cocos Islands",
        "timezone": "Indian/Cocos",
        "gmtoffset": "UTC +06:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CO",
        "countryname": "Colombia",
        "timezone": "America/Bogota",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KM",
        "countryname": "Comoros",
        "timezone": "Indian/Comoro",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CK",
        "countryname": "Cook Islands",
        "timezone": "Pacific/Rarotonga",
        "gmtoffset": "UTC -10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CR",
        "countryname": "Costa Rica",
        "timezone": "America/Costa_Rica",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "HR",
        "countryname": "Croatia",
        "timezone": "Europe/Zagreb",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CU",
        "countryname": "Cuba",
        "timezone": "America/Havana",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CW",
        "countryname": "Cura\u00c3\u00a7ao",
        "timezone": "America/Curacao",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CY",
        "countryname": "Cyprus",
        "timezone": "Asia/Famagusta",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CY",
        "countryname": "Cyprus",
        "timezone": "Asia/Nicosia",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CZ",
        "countryname": "Czech Republic",
        "timezone": "Europe/Prague",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CD",
        "countryname": "Democratic Republic of the Congo",
        "timezone": "Africa/Kinshasa",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CD",
        "countryname": "Democratic Republic of the Congo",
        "timezone": "Africa/Lubumbashi",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DK",
        "countryname": "Denmark",
        "timezone": "Europe/Copenhagen",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DJ",
        "countryname": "Djibouti",
        "timezone": "Africa/Djibouti",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DM",
        "countryname": "Dominica",
        "timezone": "America/Dominica",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DO",
        "countryname": "Dominican Republic",
        "timezone": "America/Santo_Domingo",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "TL",
        "countryname": "East Timor",
        "timezone": "Asia/Dili",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "EC",
        "countryname": "Ecuador",
        "timezone": "America/Guayaquil",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "EC",
        "countryname": "Ecuador",
        "timezone": "Pacific/Galapagos",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "EG",
        "countryname": "Egypt",
        "timezone": "Africa/Cairo",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SV",
        "countryname": "El Salvador",
        "timezone": "America/El_Salvador",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GQ",
        "countryname": "Equatorial Guinea",
        "timezone": "Africa/Malabo",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ER",
        "countryname": "Eritrea",
        "timezone": "Africa/Asmara",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "EE",
        "countryname": "Estonia",
        "timezone": "Europe/Tallinn",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ET",
        "countryname": "Ethiopia",
        "timezone": "Africa/Addis_Ababa",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FK",
        "countryname": "Falkland Islands",
        "timezone": "Atlantic/Stanley",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FO",
        "countryname": "Faroe Islands",
        "timezone": "Atlantic/Faroe",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FJ",
        "countryname": "Fiji",
        "timezone": "Pacific/Fiji",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FI",
        "countryname": "Finland",
        "timezone": "Europe/Helsinki",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FR",
        "countryname": "France",
        "timezone": "Europe/Paris",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GF",
        "countryname": "French Guiana",
        "timezone": "America/Cayenne",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PF",
        "countryname": "French Polynesia",
        "timezone": "Pacific/Gambier",
        "gmtoffset": "UTC -09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PF",
        "countryname": "French Polynesia",
        "timezone": "Pacific/Marquesas",
        "gmtoffset": "UTC -09:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PF",
        "countryname": "French Polynesia",
        "timezone": "Pacific/Tahiti",
        "gmtoffset": "UTC -10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "TF",
        "countryname": "French Southern Territories",
        "timezone": "Indian/Kerguelen",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GA",
        "countryname": "Gabon",
        "timezone": "Africa/Libreville",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GM",
        "countryname": "Gambia",
        "timezone": "Africa/Banjul",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GE",
        "countryname": "Georgia",
        "timezone": "Asia/Tbilisi",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DE",
        "countryname": "Germany",
        "timezone": "Europe/Berlin",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "DE",
        "countryname": "Germany",
        "timezone": "Europe/Busingen",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GH",
        "countryname": "Ghana",
        "timezone": "Africa/Accra",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GI",
        "countryname": "Gibraltar",
        "timezone": "Europe/Gibraltar",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GR",
        "countryname": "Greece",
        "timezone": "Europe/Athens",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GL",
        "countryname": "Greenland",
        "timezone": "America/Danmarkshavn",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GL",
        "countryname": "Greenland",
        "timezone": "America/Godthab",
        "gmtoffset": "UTC -02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GL",
        "countryname": "Greenland",
        "timezone": "America/Scoresbysund",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GL",
        "countryname": "Greenland",
        "timezone": "America/Thule",
        "gmtoffset": "UTC -03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GD",
        "countryname": "Grenada",
        "timezone": "America/Grenada",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GP",
        "countryname": "Guadeloupe",
        "timezone": "America/Guadeloupe",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GU",
        "countryname": "Guam",
        "timezone": "Pacific/Guam",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GT",
        "countryname": "Guatemala",
        "timezone": "America/Guatemala",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GG",
        "countryname": "Guernsey",
        "timezone": "Europe/Guernsey",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GN",
        "countryname": "Guinea",
        "timezone": "Africa/Conakry",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GW",
        "countryname": "Guinea-Bissau",
        "timezone": "Africa/Bissau",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GY",
        "countryname": "Guyana",
        "timezone": "America/Guyana",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "HT",
        "countryname": "Haiti",
        "timezone": "America/Port-au-Prince",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "HN",
        "countryname": "Honduras",
        "timezone": "America/Tegucigalpa",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "HK",
        "countryname": "Hong Kong",
        "timezone": "Asia/Hong_Kong",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "HU",
        "countryname": "Hungary",
        "timezone": "Europe/Budapest",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IS",
        "countryname": "Iceland",
        "timezone": "Atlantic/Reykjavik",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IN",
        "countryname": "India",
        "timezone": "Asia/Kolkata",
        "gmtoffset": "UTC +05:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ID",
        "countryname": "Indonesia",
        "timezone": "Asia/Jayapura",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ID",
        "countryname": "Indonesia",
        "timezone": "Asia/Makassar",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ID",
        "countryname": "Indonesia",
        "timezone": "Asia/Pontianak",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IR",
        "countryname": "Iran",
        "timezone": "Asia/Tehran",
        "gmtoffset": "UTC +04:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IQ",
        "countryname": "Iraq",
        "timezone": "Asia/Baghdad",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IE",
        "countryname": "Ireland",
        "timezone": "Europe/Dublin",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IM",
        "countryname": "Isle of Man",
        "timezone": "Europe/Isle_of_Man",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IL",
        "countryname": "Israel",
        "timezone": "Asia/Jerusalem",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "IT",
        "countryname": "Italy",
        "timezone": "Europe/Rome",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "CI",
        "countryname": "Ivory Coast",
        "timezone": "Africa/Abidjan",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "JM",
        "countryname": "Jamaica",
        "timezone": "America/Jamaica",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "JP",
        "countryname": "Japan",
        "timezone": "Asia/Tokyo",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "JE",
        "countryname": "Jersey",
        "timezone": "Europe/Jersey",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "JO",
        "countryname": "Jordan",
        "timezone": "Asia/Amman",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KZ",
        "countryname": "Kazakhstan",
        "timezone": "Asia/Almaty",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KZ",
        "countryname": "Kazakhstan",
        "timezone": "Asia/Aqtau",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KZ",
        "countryname": "Kazakhstan",
        "timezone": "Asia/Aqtobe",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KZ",
        "countryname": "Kazakhstan",
        "timezone": "Asia/Atyrau",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KZ",
        "countryname": "Kazakhstan",
        "timezone": "Asia/Oral",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KZ",
        "countryname": "Kazakhstan",
        "timezone": "Asia/Qyzylorda",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KE",
        "countryname": "Kenya",
        "timezone": "Africa/Nairobi",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KI",
        "countryname": "Kiribati",
        "timezone": "Pacific/Enderbury",
        "gmtoffset": "UTC +13:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KI",
        "countryname": "Kiribati",
        "timezone": "Pacific/Kiritimati",
        "gmtoffset": "UTC +14:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KI",
        "countryname": "Kiribati",
        "timezone": "Pacific/Tarawa",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KW",
        "countryname": "Kuwait",
        "timezone": "Asia/Kuwait",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KG",
        "countryname": "Kyrgyzstan",
        "timezone": "Asia/Bishkek",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LA",
        "countryname": "Laos",
        "timezone": "Asia/Vientiane",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LV",
        "countryname": "Latvia",
        "timezone": "Europe/Riga",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LB",
        "countryname": "Lebanon",
        "timezone": "Asia/Beirut",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LS",
        "countryname": "Lesotho",
        "timezone": "Africa/Maseru",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LR",
        "countryname": "Liberia",
        "timezone": "Africa/Monrovia",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LY",
        "countryname": "Libya",
        "timezone": "Africa/Tripoli",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LI",
        "countryname": "Liechtenstein",
        "timezone": "Europe/Vaduz",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LT",
        "countryname": "Lithuania",
        "timezone": "Europe/Vilnius",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LU",
        "countryname": "Luxembourg",
        "timezone": "Europe/Luxembourg",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MO",
        "countryname": "Macao",
        "timezone": "Asia/Macau",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MK",
        "countryname": "Macedonia",
        "timezone": "Europe/Skopje",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MG",
        "countryname": "Madagascar",
        "timezone": "Indian/Antananarivo",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MW",
        "countryname": "Malawi",
        "timezone": "Africa/Blantyre",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MY",
        "countryname": "Malaysia",
        "timezone": "Asia/Kuala_Lumpur",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MY",
        "countryname": "Malaysia",
        "timezone": "Asia/Kuching",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MV",
        "countryname": "Maldives",
        "timezone": "Indian/Maldives",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ML",
        "countryname": "Mali",
        "timezone": "Africa/Bamako",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MT",
        "countryname": "Malta",
        "timezone": "Europe/Malta",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MH",
        "countryname": "Marshall Islands",
        "timezone": "Pacific/Kwajalein",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MH",
        "countryname": "Marshall Islands",
        "timezone": "Pacific/Majuro",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MQ",
        "countryname": "Martinique",
        "timezone": "America/Martinique",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MR",
        "countryname": "Mauritania",
        "timezone": "Africa/Nouakchott",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MU",
        "countryname": "Mauritius",
        "timezone": "Indian/Mauritius",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "YT",
        "countryname": "Mayotte",
        "timezone": "Indian/Mayotte",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Bahia_Banderas",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Cancun",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Chihuahua",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Hermosillo",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Matamoros",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Mazatlan",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Merida",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Mexico_City",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Monterrey",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Ojinaga",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MX",
        "countryname": "Mexico",
        "timezone": "America/Tijuana",
        "gmtoffset": "UTC -07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FM",
        "countryname": "Micronesia",
        "timezone": "Pacific/Chuuk",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FM",
        "countryname": "Micronesia",
        "timezone": "Pacific/Kosrae",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "FM",
        "countryname": "Micronesia",
        "timezone": "Pacific/Pohnpei",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MD",
        "countryname": "Moldova",
        "timezone": "Europe/Chisinau",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MC",
        "countryname": "Monaco",
        "timezone": "Europe/Monaco",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MN",
        "countryname": "Mongolia",
        "timezone": "Asia/Choibalsan",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MN",
        "countryname": "Mongolia",
        "timezone": "Asia/Hovd",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MN",
        "countryname": "Mongolia",
        "timezone": "Asia/Ulaanbaatar",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ME",
        "countryname": "Montenegro",
        "timezone": "Europe/Podgorica",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MS",
        "countryname": "Montserrat",
        "timezone": "America/Montserrat",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MA",
        "countryname": "Morocco",
        "timezone": "Africa/Casablanca",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MZ",
        "countryname": "Mozambique",
        "timezone": "Africa/Maputo",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MM",
        "countryname": "Myanmar",
        "timezone": "Asia/Yangon",
        "gmtoffset": "UTC +06:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NA",
        "countryname": "Namibia",
        "timezone": "Africa/Windhoek",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NR",
        "countryname": "Nauru",
        "timezone": "Pacific/Nauru",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NP",
        "countryname": "Nepal",
        "timezone": "Asia/Kathmandu",
        "gmtoffset": "UTC +05:45",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NL",
        "countryname": "Netherlands",
        "timezone": "Europe/Amsterdam",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NC",
        "countryname": "New Caledonia",
        "timezone": "Pacific/Noumea",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NZ",
        "countryname": "New Zealand",
        "timezone": "Pacific/Chatham",
        "gmtoffset": "UTC +12:45",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NI",
        "countryname": "Nicaragua",
        "timezone": "America/Managua",
        "gmtoffset": "UTC -06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NE",
        "countryname": "Niger",
        "timezone": "Africa/Niamey",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NG",
        "countryname": "Nigeria",
        "timezone": "Africa/Lagos",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NU",
        "countryname": "Niue",
        "timezone": "Pacific/Niue",
        "gmtoffset": "UTC -11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NF",
        "countryname": "Norfolk Island",
        "timezone": "Pacific/Norfolk",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KP",
        "countryname": "North Korea",
        "timezone": "Asia/Pyongyang",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MP",
        "countryname": "Northern Mariana Islands",
        "timezone": "Pacific/Saipan",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "NO",
        "countryname": "Norway",
        "timezone": "Europe/Oslo",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "OM",
        "countryname": "Oman",
        "timezone": "Asia/Muscat",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PK",
        "countryname": "Pakistan",
        "timezone": "Asia/Karachi",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PW",
        "countryname": "Palau",
        "timezone": "Pacific/Palau",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PS",
        "countryname": "Palestinian Territory",
        "timezone": "Asia/Gaza",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PS",
        "countryname": "Palestinian Territory",
        "timezone": "Asia/Hebron",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PA",
        "countryname": "Panama",
        "timezone": "America/Panama",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PG",
        "countryname": "Papua New Guinea",
        "timezone": "Pacific/Bougainville",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PG",
        "countryname": "Papua New Guinea",
        "timezone": "Pacific/Port_Moresby",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PY",
        "countryname": "Paraguay",
        "timezone": "America/Asuncion",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PE",
        "countryname": "Peru",
        "timezone": "America/Lima",
        "gmtoffset": "UTC -05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PH",
        "countryname": "Philippines",
        "timezone": "Asia/Manila",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PN",
        "countryname": "Pitcairn",
        "timezone": "Pacific/Pitcairn",
        "gmtoffset": "UTC -08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PL",
        "countryname": "Poland",
        "timezone": "Europe/Warsaw",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PT",
        "countryname": "Portugal",
        "timezone": "Atlantic/Azores",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PT",
        "countryname": "Portugal",
        "timezone": "Atlantic/Madeira",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PT",
        "countryname": "Portugal",
        "timezone": "Europe/Lisbon",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PR",
        "countryname": "Puerto Rico",
        "timezone": "America/Puerto_Rico",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "QA",
        "countryname": "Qatar",
        "timezone": "Asia/Qatar",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RE",
        "countryname": "Reunion",
        "timezone": "Indian/Reunion",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RO",
        "countryname": "Romania",
        "timezone": "Europe/Bucharest",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Anadyr",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Barnaul",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Chita",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Irkutsk",
        "gmtoffset": "UTC +08:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Kamchatka",
        "gmtoffset": "UTC +12:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Khandyga",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Krasnoyarsk",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Magadan",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Novokuznetsk",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Novosibirsk",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Omsk",
        "gmtoffset": "UTC +06:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Sakhalin",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Srednekolymsk",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Tomsk",
        "gmtoffset": "UTC +07:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Ust-Nera",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Vladivostok",
        "gmtoffset": "UTC +10:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Yakutsk",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Asia/Yekaterinburg",
        "gmtoffset": "UTC +05:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Astrakhan",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Kaliningrad",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Kirov",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Moscow",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Samara",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Saratov",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Simferopol",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Ulyanovsk",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RU",
        "countryname": "Russia",
        "timezone": "Europe/Volgograd",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RW",
        "countryname": "Rwanda",
        "timezone": "Africa/Kigali",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "BL",
        "countryname": "Saint Barth\u00c3\u00a9lemy",
        "timezone": "America/St_Barthelemy",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SH",
        "countryname": "Saint Helena",
        "timezone": "Atlantic/St_Helena",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KN",
        "countryname": "Saint Kitts and Nevis",
        "timezone": "America/St_Kitts",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LC",
        "countryname": "Saint Lucia",
        "timezone": "America/St_Lucia",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "MF",
        "countryname": "Saint Martin",
        "timezone": "America/Marigot",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "PM",
        "countryname": "Saint Pierre and Miquelon",
        "timezone": "America/Miquelon",
        "gmtoffset": "UTC -02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "VC",
        "countryname": "Saint Vincent and the Grenadines",
        "timezone": "America/St_Vincent",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "WS",
        "countryname": "Samoa",
        "timezone": "Pacific/Apia",
        "gmtoffset": "UTC +13:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SM",
        "countryname": "San Marino",
        "timezone": "Europe/San_Marino",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ST",
        "countryname": "Sao Tome and Principe",
        "timezone": "Africa/Sao_Tome",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SA",
        "countryname": "Saudi Arabia",
        "timezone": "Asia/Riyadh",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SN",
        "countryname": "Senegal",
        "timezone": "Africa/Dakar",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "RS",
        "countryname": "Serbia",
        "timezone": "Europe/Belgrade",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SC",
        "countryname": "Seychelles",
        "timezone": "Indian/Mahe",
        "gmtoffset": "UTC +04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SL",
        "countryname": "Sierra Leone",
        "timezone": "Africa/Freetown",
        "gmtoffset": "UTC",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SX",
        "countryname": "Sint Maarten",
        "timezone": "America/Lower_Princes",
        "gmtoffset": "UTC -04:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SK",
        "countryname": "Slovakia",
        "timezone": "Europe/Bratislava",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SI",
        "countryname": "Slovenia",
        "timezone": "Europe/Ljubljana",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SB",
        "countryname": "Solomon Islands",
        "timezone": "Pacific/Guadalcanal",
        "gmtoffset": "UTC +11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SO",
        "countryname": "Somalia",
        "timezone": "Africa/Mogadishu",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "GS",
        "countryname": "South Georgia and the South Sandwich Islands",
        "timezone": "Atlantic/South_Georgia",
        "gmtoffset": "UTC -02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "KR",
        "countryname": "South Korea",
        "timezone": "Asia/Seoul",
        "gmtoffset": "UTC +09:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "SS",
        "countryname": "South Sudan",
        "timezone": "Africa/Juba",
        "gmtoffset": "UTC +03:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ES",
        "countryname": "Spain",
        "timezone": "Africa/Ceuta",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ES",
        "countryname": "Spain",
        "timezone": "Atlantic/Canary",
        "gmtoffset": "UTC +01:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "ES",
        "countryname": "Spain",
        "timezone": "Europe/Madrid",
        "gmtoffset": "UTC +02:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "LK",
        "countryname": "Sri Lanka",
        "timezone": "Asia/Colombo",
        "gmtoffset": "UTC +05:30",
        "daylightsettings": "N",
        "activeyn": "Y"
    },
    {
        "countrycode": "AS",
        "countryname": "American Samoa",
        "timezone": "Pacific/Pago_Pago",
        "gmtoffset": "UTC -11:00",
        "daylightsettings": "N",
        "activeyn": "Y"
    }
]


# Insert data with error handling for potential duplicate key violations
if not Role.query.first():
    for data in role_data:
        entry = Role(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not Languages.query.first():
    for data in language_data:
        entry = Languages(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not Region.query.first():
    for data in region_data:
        entry = Region(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not Permission.query.first():
    for data in permission_data:
        entry = Permission(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not SubscriptionType.query.first():
    for data in subscription_data:
        entry = SubscriptionType(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not Tab.query.first():
    for data in tab_data:
        entry = Tab(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not RoleTabPermission.query.first():
    for data in roletabpermission_data:
        entry = RoleTabPermission(**data)
        session.add(entry)
        session.commit()
else:
    pass

if not TimeZone.query.first():
    for data in timezone_data:
        entry = TimeZone(**data)
        session.add(entry)
        session.commit()
else:
    pass

nano_value=[
    {
        'nano_id':'refids',
        'status':'inactive'
    }

]
if not Nano.query.first():
    for data in nano_value:
        entry = Nano(**data)
        session.add(entry)
        session.commit()
else:
    pass
# Close the session
session.close()



