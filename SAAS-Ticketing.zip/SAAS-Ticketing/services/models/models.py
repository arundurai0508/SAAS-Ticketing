from services import db

class Tenant(db.Model):
    __tablename__ = 'Tenant'
    tenantid = db.Column(db.Integer, primary_key=True)
    businessname = db.Column(db.String, nullable=False, unique=True)
    regionid = db.Column(db.Integer, db.ForeignKey('Region.regionid'))
    subscriptiontypeid = db.Column(db.Integer, db.ForeignKey('SubscriptionType.subscriptiontypeid'))
    customeruniqueid = db.Column(db.String, unique=True) #Nano_id (only use for payment)

class User(db.Model):
    __tablename__ = 'User'
    userid = db.Column(db.Integer, primary_key=True)
    tenantid = db.Column(db.Integer, db.ForeignKey('Tenant.tenantid'))
    email = db.Column(db.String, nullable=False, unique=True)
    password = db.Column(db.String, unique=True) #hashlib
    language = db.Column(db.Integer, db.ForeignKey('Languages.languageid'))
    createdate = db.Column(db.TIMESTAMP) #without timezone default UTC now
    lastactive = db.Column(db.TIMESTAMP)
    lockout_time= db.Column(db.TIMESTAMP)
    attempts = db.Column(db.Integer)
    activeyn = db.Column(db.String(1))
    firsttimelogin=db.Column(db.String(1))
    timezoneid = db.Column(db.Integer, db.ForeignKey('TimeZone.zoneid'))
    otp=db.Column(db.String,unique=True)
    otpcreationtime=db.Column(db.TIMESTAMP)

class UserRole(db.Model):
    __tablename__ = 'UserRole'
    userroleid = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.Integer, db.ForeignKey('User.userid'))
    roleid = db.Column(db.Integer, db.ForeignKey('Role.roleid'))

class Session(db.Model):
    __tablename__ = 'Session'
    Sessionid = db.Column(db.Integer, primary_key=True)
    tenantid = db.Column(db.Integer, db.ForeignKey('Tenant.tenantid'))
    userid = db.Column(db.Integer, db.ForeignKey('User.userid'))
    sessionkeys = db.Column(db.String)
    activeyn = db.Column(db.String)
    logintime = db.Column(db.TIMESTAMP)
# Role table class
class Role(db.Model):
    __tablename__ = 'Role'
    roleid = db.Column(db.Integer, primary_key=True)
    rolename = db.Column(db.String(50))  # Set unique constraint on rolename
    description = db.Column(db.String(100), default='description')

# Language table class
class Languages(db.Model):
    __tablename__ = 'Languages'
    languageid = db.Column(db.Integer, primary_key=True)
    language = db.Column(db.String, default='language')  # Set unique constraint on language

# Region table class
class Region(db.Model):
    __tablename__ = 'Region'
    regionid = db.Column(db.Integer, primary_key=True)
    region = db.Column(db.String, default='region')

# Permission table class
class Permission(db.Model):
    __tablename__ = 'Permission'
    permissionid = db.Column(db.Integer, primary_key=True)
    permissionname = db.Column(db.String, default='region')
    description = db.Column(db.String, default='default')

# SubscriptionType table class
class SubscriptionType(db.Model):
    __tablename__ = 'SubscriptionType'
    subscriptiontypeid = db.Column(db.Integer, primary_key=True)
    typename = db.Column(db.String, default='trail')
    maxprojects = db.Column(db.Integer, default=0)
    maxworkflows = db.Column(db.Integer, default=0)
    maxtasks = db.Column(db.Integer, default=0)
    maxusers = db.Column(db.Integer, default=0)

# Tab table class
class Tab(db.Model):
    __tablename__ = 'Tab'
    tabid = db.Column(db.Integer, primary_key=True)
    tabname = db.Column(db.String, default="name")
    description = db.Column(db.String, default="describe")

# RoleTabPermission table class
class RoleTabPermission(db.Model):
    __tablename__ = 'RoleTabPermission'
    rolepermissionid = db.Column(db.Integer, primary_key=True)
    roleid = db.Column(db.Integer, db.ForeignKey('Role.roleid'),  default=0)
    tabid = db.Column(db.Integer, db.ForeignKey('Tab.tabid'), default=0)
    permissionid = db.Column(db.Integer, db.ForeignKey('Permission.permissionid'), default=0)

# Role Permission table class
class TimeZone(db.Model):
    __tablename__ = 'TimeZone'
    zoneid = db.Column(db.Integer, primary_key=True)
    countrycode = db.Column(db.String, default="0")
    countryname = db.Column(db.String, default="0")
    timezone = db.Column(db.String, default="0")
    gmtoffset = db.Column(db.String, default="0")
    activeyn = db.Column(db.String, default="0")
    daylightsettings= db.Column(db.String, default="0")

class Nano(db.Model):
    __tablename__ = 'Nano'
    pk_nano_id = db.Column(db.Integer,primary_key=True)
    nano_id = db.Column(db.String(50), nullable=False, unique=True)
    status = db.Column(db.String(255), nullable=False)

class Temp_User(db.Model):
    __tablename__ = 'Temp_User'
    tempuserid = db.Column(db.Integer,primary_key=True)
    email = db.Column(db.String(50), nullable=False)
    businessname = db.Column(db.String(255), nullable=False)
    otp = db.Column(db.String)
    creationtime=db.Column(db.DateTime)