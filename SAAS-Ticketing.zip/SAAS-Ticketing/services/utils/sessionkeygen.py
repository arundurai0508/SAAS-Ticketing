#import secrets
#from services.utils.ConnPostgreSQL import returnSelectQueryResult, returnInsertResult
import binascii
import os
from services import db
import jwt
from datetime import datetime,timedelta
from services.models.models import Session, User, TimeZone
from config import config


def createSession(sUserID):
    try:
        k = binascii.hexlify(os.urandom(64))
        k = k.decode('utf-8')
        tenant=User.query.filter_by(userid=sUserID).first()
        new_session = Session(
            tenantid=tenant.tenantid,
            userid=sUserID,
            sessionkeys=k,
            activeyn='y',
            logintime=datetime.utcnow()
        )
        db.session.add(new_session)
        db.session.commit()


        return {"result": "success", "data": k}

    except Exception as e:
        print(e)
        db.session.rollback()
        return {"result": "failure", "data": "Server is busy. Cannot login now. Try after sometimes"}



def getUserDetailsBasedWithSessionKey(sKey):

    try:
        userid = Session.query.filter(Session.session_key==sKey).filter(Session.active_yn=='Y').first()

        user = User.query.filter(User.pk_user_details_id==userid.fk_user_id).first()

        Zone=TimeZone.query.filter(TimeZone.zoneid==user.fk_time_zone_id).first()
        results=[{
           " user_id":user.user_id,
            "time_zone":Zone.time_zone
        }]

        return {"results":results}


    except:
        return {"results": "failure", "data": "unable to fetch user's timezone based on sessionkey"}
