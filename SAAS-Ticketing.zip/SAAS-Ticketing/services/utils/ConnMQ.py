import json
import pika

from config.config import Config as cfg

def send2MQ(pQueue, pExchange, pRoutingKey, pData):

    credentials = pika.PlainCredentials(cfg.RABBITMQUSER, cfg.RABBITMQPWD)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=cfg.RABBITMQIP,credentials=credentials,virtual_host=cfg.RABBITMQVHOST))
    channel = connection.channel()
    channel.queue_declare(queue=pQueue, durable=True)
    channel.queue_bind(queue=pQueue, exchange=pExchange)
    channel.basic_publish(exchange=pExchange, routing_key=pRoutingKey, body=json.dumps(pData))
    connection.close()
    return {'result': 'success', 'data': 'Successfully pushed data to ESB'}