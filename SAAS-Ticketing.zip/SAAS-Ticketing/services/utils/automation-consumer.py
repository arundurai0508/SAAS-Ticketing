import paramiko

from pysnmp.hlapi import *
import json

import pika
from config.config import Config as cfg
import traceback


def callback(ch, method, properties, body):
    try:
        data=json.loads(body)
        nano_id=data['nano_id']
        print(nano_id)
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        private_key = paramiko.RSAKey.from_private_key_file("C:/Users/saranya/PycharmProjects/saas-automation/autointelli_aws.pem")
        ssh_client.connect("65.2.83.154", port=22, username="ubuntu", pkey=private_key)
        # command='su -otrs;cd /opt/otrs/bin;/otrs.Console.pl Admin::CustomerUser::Add --user-name testuser --first-name test --last-name user --password testuser --email-address testuser@gmail.com --customer-id 1'
        # command = 'su -otrs;cd /opt/otrs/bin;su -c "./otrs.Console.pl Admin::CustomerUser::Add --user-name testuser14 --first-name test1 --last-name user1 --password testuser --email-address testuser14@gmail.com --customer-id 1" -s /bin/bash otrs'
        # command="ansible-playbook -e 'nano_id=cfive' without.yml"
        print(nano_id)
        print("Machine Connected")
        # stdin, stdout, stderr = ssh_client.exec_command(
        #     f'sudo su;cd root;cd Ansible;ansible-playbook -e "nano_id={nano_id}" without.yml')

        #ssh_client.exec_command('sudo su')
        # ssh_client.exec_command('cd /')
        # ssh_client.exec_command('cd root/')
        #ssh_client.exec_command('cd Ansible')
        command=f'sudo -i  ansible-playbook -e "nano_id={nano_id}" /root/Ansible/without.yml'
        stdin, stdout, stderr = ssh_client.exec_command(command)
        print(stdout.readlines())


    except Exception as e:
        print(e)
    finally:
        ssh_client.close()
    channel.basic_ack(delivery_tag=method.delivery_tag)

try:
    # Get the details of MQ

    credentials = pika.PlainCredentials(cfg.RABBITMQUSER, cfg.RABBITMQPWD)
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=cfg.RABBITMQIP,credentials=credentials,virtual_host=cfg.RABBITMQVHOST))
    channel = connection.channel()
    channel.queue_declare(queue='automation', durable=True)
    channel.queue_bind(exchange='saas', queue='automation')
    channel.basic_consume('automation', callback, auto_ack=False)
    channel.basic_qos(prefetch_count=1)
    channel.start_consuming()
    # channel.close()
except Exception as e:
    print("Worker failed. Reason:" + str(e))
    print("Worker failed. Reason:" + str(e))


