
from flask import request
from services.models.models import Session

def lam_api_key_missing():
    return ({"result": "failure", "data": "api-key missing"})

def lam_api_key_invalid():
    return ({"result": "failure", "data": "invalid api-key"})

def chkValidRequest(key):

    key = Session.query.filter(Session.sessionkeys == request.headers["SESSIONKEY"]).filter(Session.activeyn=='y').first()
    if key is not None:
        print(key)
        #logINFO("New Session {0}".format(key))
        return True
    else:
        #logWARN("Invalid session access {0}".format(key))
        return False


def chkKeyExistsInHeader(key):
    try:
        tmp = request.headers[key]
        return True
    except KeyError as e:
        #logWARN("Foreign Entry")
        return False
    except Exception as e:
        #logERROR("Exception: {0}".format(str(e)))
        return False
