from flask import Flask, request, jsonify
from datetime import datetime
import re
from services import app
from config.config import DB_Connection
from flasgger import Swagger, swag_from
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader

swagger_loc = app.config['SWAGGER_LOC']


def sanitize_name(character):
    return re.sub(r'[+\-*/!#$%^&|_<?{}>0123456789]', '', character)


@swag_from(swagger_loc + "/State/create.yml")
@app.route('/api/State/create', methods=['POST'])
def create_State():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                name = data.get('name')
                comments = data.get('comments')
                type_id = data.get('type_id')
                valid_id = 1
                login_user = data.get('login_user')

                current_time = datetime.now()

                if not all([name, comments, type_id, valid_id, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_name = sanitize_name(name)
                sanitized_comments = sanitize_name(comments)

                if name != sanitized_name or comments != sanitized_comments:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                type_query = (f'SELECT id FROM ticket_state_type where name = "{type_id}";')
                cursor.execute(type_query, )
                type_row = cursor.fetchone()
                if not type_row:
                    return jsonify({"error": "StateType not found"}), 404
                type_name = type_row[0]

                sql = """INSERT INTO ticket_state (name, comments, type_id, valid_id, create_time, create_by, 
                change_time, change_by) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"""

                cursor.execute(sql, (name, comments, type_name, valid_id, current_time, login_name, current_time, login_name))

                db_connection.commit()

                return jsonify({'message': 'State created successfully'}), 201

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/State/update.yml")
@app.route('/api/State/update', methods=['PUT'])
def update_State():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                id = data.get('id')
                name = data.get('name')
                comments = data.get('comments')
                type_id = data.get('type_id')
                valid_id = data.get('valid_id')
                login_user = data.get('login_user')
                current_time = datetime.now()

                if not all([name, comments, type_id, valid_id, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_name = sanitize_name(name)
                sanitized_comments = sanitize_name(comments)

                if name != sanitized_name or comments != sanitized_comments:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = "SELECT * FROM ticket_state WHERE id = ?"
                cursor.execute(sql, (id,))
                data = cursor.fetchone()
                if data:

                    type_query = (f'SELECT id FROM ticket_state_type where name = "{type_id}";')
                    cursor.execute(type_query, )
                    type_row = cursor.fetchone()
                    if not type_row:
                        return jsonify({"error": "StateType not found"}), 404
                    type_name = type_row[0]

                    valid_query = (f'SELECT id FROM valid where name = "{valid_id}";')
                    cursor.execute(valid_query, )
                    valid_row = cursor.fetchone()
                    if not valid_row:
                        return jsonify({"error": "Valid ID not found"}), 404
                    valid = valid_row[0]

                    sql = """UPDATE ticket_state SET name = %s, comments = %s, type_id = %s, valid_id = %s, change_time = %s, 
                    change_by = %s WHERE id = %s;"""

                    cursor.execute(sql, (name, comments, type_name, valid, current_time, login_name, id))

                    return jsonify({'message': 'State updated successfully'}), 200
                else:
                    return jsonify({'error': 'State not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/State/get_all.yml")
@app.route('/api/State/get_all', methods=['GET'])
def get_all_State():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                sql = "SELECT * FROM ticket_state"
                cursor.execute(sql)
                data = []
                for row in cursor.fetchall():
                    state_dict = {
                        'state_id': row[0],
                        'state_name': row[1],
                        'comments': row[2],
                        'state_type_id': row[3]
                    }
                    data.append(state_dict)
                return jsonify({'data': data}), 200

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/State/get_single.yml")
@app.route('/api/State/get_single', methods=['GET'])
def get_single_State():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                id = request.args.get('id')
                cursor = db_connection.cursor()
                sql = "SELECT * FROM ticket_state WHERE id = ?;"
                cursor.execute(sql, (id,))
                row = cursor.fetchone()

                if row:
                    state_dict = {
                        'state_id': row[0],
                        'state_name': row[1],
                        'comments': row[2],
                        'state_type_id': row[3]
                    }
                    return jsonify({'data': state_dict}), 200
                else:
                    return jsonify({'error': 'State not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400



