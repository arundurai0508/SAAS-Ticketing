from flask import Flask, request, jsonify
from pyotrs import Client, Ticket, Article
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader
from datetime import datetime
import re
from services import app
from config.config import DB_Connection

from flasgger import Swagger, swag_from
from config.config import OTRS_URL

UL = OTRS_URL.url
UN = OTRS_URL.username
PW = OTRS_URL.password

db_connection = DB_Connection()

swagger_loc = app.config['SWAGGER_LOC']


class TicketConnector:
    def __init__(self, url, username, password):
        self.url = url
        self.username = username
        self.password = password
        self.client = Client(url, username, password)


ticket_connector = TicketConnector(UL, UN, PW)


@swag_from(swagger_loc + "/Ticket/create.yml")
@app.route('/api/ticket/create', methods=['POST'])
def create_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                if ticket_connector.client.session_create():
                    data = request.json

                    title = data.get('title')
                    queue = data.get('queue')
                    state = data.get('state')
                    priority = data.get('priority')
                    cus_user = data.get('cus_user')
                    subject = data.get('subject')
                    body = data.get('body')

                    new_ticket = Ticket.create_basic(
                        Title=title, Queue=queue, State=state, Priority=priority, CustomerUser=cus_user
                    )

                    first_article = Article({"Subject": subject, "Body": body})

                    result = ticket_connector.client.ticket_create(ticket=new_ticket, article=first_article)

                    return {"status": "success", "message": "Ticket created successfully", "Ticket Details": result}, 201

            except Exception as e:
                return {"status": "error", "message": f"An unexpected error occurred: {e}"}, 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/update.yml")
@app.route('/api/ticket/update', methods=['PUT'])
def update_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                data = request.get_json()
                ticket_id = data.get('id')
                title = data.get('title')
                queue = data.get('queue')
                priority = data.get('priority')
                state = data.get('state')


                if ticket_id is None:
                    return jsonify({"status": "error", "message": "Missing ticket_id:'ticket_id'"}), 400

                if not ticket_connector.client.session_create():
                    return jsonify({"status": "error", "message": "Failed to create a session. Please try again."}), 400

                result = ticket_connector.client.ticket_update(
                    ticket_id, Title=title, Queue=queue, State=state, Priority=priority,
                )

                return jsonify({"status": "success", "message": "Ticket updated successfully", "Ticket Details": result}), 200

            except Exception as e:
                return jsonify({"status": "error", "message": f"An unexpected error occurred: {e}"}), 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/get_single.yml")
@app.route('/api/ticket/get_single', methods=['GET'])
def get_single_ticket():
    try:
        ticket_id = request.args.get('id')
        if ticket_id is None:
            return jsonify({"status": "error", "message": "Ticket ID is missing"}), 400

        client = ticket_connector.client
        if client.session_create():
            ticket = client.ticket_get_by_id(ticket_id, articles=True, attachments=True, dynamic_fields=True)
            if ticket:
                ticket_data = {
                    "id": ticket_id,
                    "title": ticket.field_get("Title"),
                    "queue": ticket.field_get("Queue"),
                    "state": ticket.field_get("State"),
                    "priority": ticket.field_get("Priority"),
                    "cus_user": ticket.field_get("CustomerUserID"),
                }

                articles_data = []
                if hasattr(ticket, 'Articles'):
                    for article in ticket.Articles:
                        articles_data.append({"Subject": article.Subject, "Body": article.Body})

                return jsonify({"Ticket": ticket_data, "Articles": articles_data})
            else:
                return jsonify({"status": "error", "message": "Ticket not found"}), 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400


@swag_from(swagger_loc + "/Ticket/CustomerUser_ticket_get_all.yml")
@app.route("/api/CustomerUser/ticket/get_all", methods=["GET"])
def customer_user_fetch_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                customer_username = request.args.get('Customer_Username')
                if ticket_connector.client.session_create():
                    ticket_ids = ticket_connector.client.ticket_search()
                    if isinstance(ticket_ids, list):
                        ticket_details = []
                        ticket_count = 0
                        for ticket_id in ticket_ids:
                            try:
                                ticket = ticket_connector.client.ticket_get_by_id(ticket_id)
                                if ticket:
                                    if ticket.field_get("CustomerUserID") == customer_username:
                                        ticket_info = {
                                            "id": ticket_id,
                                            "title": ticket.field_get("Title"),
                                            "queue": ticket.field_get("Queue"),
                                            "state": ticket.field_get("State"),
                                            "priority": ticket.field_get("Priority"),
                                        }
                                        if hasattr(ticket, 'Articles') and ticket.Articles:
                                            ticket_info["subject"] = ticket.Articles[0].Subject
                                            ticket_info["body"] = ticket.Articles[0].Body
                                        ticket_details.append(ticket_info)

                                    if ticket.field_get("CustomerUserID") == customer_username:
                                        ticket_count += 1
                            except Exception as e:
                                continue
                        return {"status": "success", "tickets": ticket_details, "ticket_count": ticket_count}, 200
                    else:
                        return {"status": "error", "message": "Unexpected response format"}, 400
            except Exception as e:
                return {"status": "error", "message": str(e)}, 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/CustomerUser_ticket_state_get_all.yml")
@app.route("/api/CustomerUser/ticket/state/get_all", methods=["GET"])
def state_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                customer_username = request.args.get('Customer_Username')
                state_filter = request.args.get('state')
                if ticket_connector.client.session_create():
                    ticket_ids = ticket_connector.client.ticket_search()
                    if isinstance(ticket_ids, list):
                        ticket_details = []
                        ticket_count = 0
                        for ticket_id in ticket_ids:
                            try:
                                ticket = ticket_connector.client.ticket_get_by_id(ticket_id)
                                if ticket:
                                    if ticket.field_get("CustomerUserID") == customer_username:
                                        if state_filter is None or ticket.field_get(
                                                "State") == state_filter:
                                            ticket_info = {
                                                "id": ticket_id,
                                                "title": ticket.field_get("Title"),
                                                "queue": ticket.field_get("Queue"),
                                                "state": ticket.field_get("State"),
                                                "priority": ticket.field_get("Priority"),
                                            }
                                            if hasattr(ticket, 'Articles') and ticket.Articles:
                                                ticket_info["subject"] = ticket.Articles[0].Subject
                                                ticket_info["body"] = ticket.Articles[0].Body
                                            ticket_details.append(ticket_info)

                                            if ticket.field_get(
                                                    "State") == state_filter:
                                                ticket_count += 1
                            except Exception as e:
                                continue

                        if not ticket_details:
                            return {"status": "success", "message": "No tickets found for the specified criteria"}, 200

                        return {"status": "success", "tickets": ticket_details, "ticket_count": ticket_count}, 200
                    else:
                        return {"status": "error", "message": "Unexpected response format"}, 400
            except Exception as e:
                return {"status": "error", "message": str(e)}, 400

            return {"status": "error", "message": "An unexpected error occurred"}, 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/AgentUser_ticket_get_all.yml")
@app.route("/api/AgentUser/ticket/get_all", methods=["GET"])
def agent_user_fetch_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                agent_username = request.args.get('Agent_Username')
                if ticket_connector.client.session_create():
                    ticket_ids = ticket_connector.client.ticket_search()
                    if isinstance(ticket_ids, list):
                        ticket_details = []
                        ticket_count = 0
                        for ticket_id in ticket_ids:
                            try:
                                ticket = ticket_connector.client.ticket_get_by_id(ticket_id)
                                if ticket:
                                    if ticket.field_get("Owner") == agent_username:
                                        ticket_info = {
                                            "id": ticket_id,
                                            "title": ticket.field_get("Title"),
                                            "queue": ticket.field_get("Queue"),
                                            "state": ticket.field_get("State"),
                                            "priority": ticket.field_get("Priority"),
                                        }
                                        if hasattr(ticket, 'Articles') and ticket.Articles:
                                            ticket_info["subject"] = ticket.Articles[0].Subject
                                            ticket_info["body"] = ticket.Articles[0].Body
                                        ticket_details.append(ticket_info)
                                        ticket_count += 1
                            except Exception as e:
                                continue
                        return {"status": "success", "tickets": ticket_details, "ticket_count": ticket_count}, 200
                    else:
                        return {"status": "error", "message": "Unexpected response format"}, 400
            except Exception as e:
                return {"status": "error", "message": str(e)}, 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/AgentUser_ticket_state_get_all.yml")
@app.route("/api/AgentUser/ticket/state/get_all", methods=["GET"])
def agent_state_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                agent_username = request.args.get('Agent_Username')
                state_filter = request.args.get('state')
                if ticket_connector.client.session_create():
                    ticket_ids = ticket_connector.client.ticket_search()
                    if isinstance(ticket_ids, list):
                        ticket_details = []
                        ticket_count = 0
                        for ticket_id in ticket_ids:
                            try:
                                ticket = ticket_connector.client.ticket_get_by_id(ticket_id)
                                if ticket:
                                    if ticket.field_get("Owner") == agent_username:
                                        if state_filter is None or ticket.field_get("State") == state_filter:
                                            ticket_info = {
                                                "id": ticket_id,
                                                "title": ticket.field_get("Title"),
                                                "queue": ticket.field_get("Queue"),
                                                "state": ticket.field_get("State"),
                                                "priority": ticket.field_get("Priority"),
                                            }
                                            if hasattr(ticket, 'Articles') and ticket.Articles:
                                                ticket_info["subject"] = ticket.Articles[0].Subject
                                                ticket_info["body"] = ticket.Articles[0].Body
                                            ticket_details.append(ticket_info)

                                            if ticket.field_get("State") == state_filter:
                                                ticket_count += 1
                            except Exception as e:
                                continue

                        if not ticket_details:
                            return {"status": "success", "message": "No tickets found for the specified criteria"}, 200

                        return {"status": "success", "tickets": ticket_details, "ticket_count": ticket_count}, 200
                    else:
                        return {"status": "error", "message": "Unexpected response format"}, 400
            except Exception as e:
                return {"status": "error", "message": str(e)}, 400

            return {"status": "error", "message": "An unexpected error occurred"}, 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400