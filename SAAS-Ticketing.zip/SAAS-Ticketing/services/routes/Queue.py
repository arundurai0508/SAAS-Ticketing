from flask import Flask, request, jsonify
from datetime import datetime
import re
from services import app
from config.config import DB_Connection
from flasgger import Swagger, swag_from
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader

swagger_loc = app.config['SWAGGER_LOC']


def sanitize_name(character):
    return re.sub(r'[+\-*/!#$%^&|<?{}>0123456789]', '', character)


@swag_from(swagger_loc + "/Queue/create.yml")
@app.route('/api/Queue/create', methods=['POST'])
def create_Queue():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                name = data.get('name')
                group_id = 1
                system_address_id = 1
                salutation_id = 1
                signature_id = 1
                follow_up_id = 1
                follow_up_lock = 1
                valid_id = 1
                comments = data.get('comments')
                login_user = data.get('login_user')

                current_time = datetime.now()

                if not all([name, comments, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_name = sanitize_name(name)
                sanitized_comments = sanitize_name(comments)

                if name != sanitized_name or comments != sanitized_comments:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = """INSERT INTO queue(name, group_id,  system_address_id, salutation_id, signature_id, 
                               follow_up_id, follow_up_lock, comments, valid_id, create_time, create_by, change_time, change_by) 
                               VALUES (%s, %s,  %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"""
                cursor.execute(sql, (
                    name, group_id, system_address_id, salutation_id, signature_id, follow_up_id, follow_up_lock,
                    comments, valid_id, current_time, login_name,
                    current_time, login_name))
                db_connection.commit()

                return jsonify({'message': 'Queue created successfully'}), 201

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Queue/update.yml")
@app.route('/api/Queue/update', methods=['PUT'])
def update_Queue():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                id = data.get('id')
                name = data.get('name')
                group_id = 1
                system_address_id = 1
                salutation_id = 1
                signature_id = 1
                follow_up_id = 1
                follow_up_lock = 1
                valid_id = data.get('valid_id')
                comments = data.get('comments')
                login_user = data.get('login_user')
                current_time = datetime.now()

                if not all([name, comments, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_name = sanitize_name(name)
                sanitized_comments = sanitize_name(comments)

                if name != sanitized_name or comments != sanitized_comments:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = "SELECT * FROM queue WHERE id = ?"
                cursor.execute(sql, (id,))
                data = cursor.fetchone()
                if data:

                    valid_query = (f'SELECT id FROM valid where name = "{valid_id}";')
                    cursor.execute(valid_query, )
                    valid_row = cursor.fetchone()
                    if not valid_row:
                        return jsonify({"error": "Valid ID not found"}), 404
                    valid = valid_row[0]

                    sql = """UPDATE queue SET name = %s, group_id = %s, system_address_id = %s, salutation_id = %s, 
                    signature_id = %s, follow_up_id = %s, follow_up_lock = %s, comments = %s, valid_id = %s, change_time = 
                    %s, change_by = %s WHERE id = %s;"""

                    cursor.execute(sql, (name, group_id, system_address_id, salutation_id, signature_id,follow_up_id, follow_up_lock, comments, valid, current_time, login_name, id))

                    db_connection.commit()

                    return jsonify({'message': 'Queue updated successfully'}), 200
                else:
                    return jsonify({'error': 'Queue not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Queue/get_all.yml")
@app.route('/api/Queue/get_all', methods=['GET'])
def get_all_Queue():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                sql = "SELECT * FROM queue"
                cursor.execute(sql)
                data = []
                for row in cursor.fetchall():
                    queue_dict = {
                        'queue_id': row[0],
                        'queue_name': row[1],
                        'group_id': row[2],
                        'comments': row[17]
                    }
                    data.append(queue_dict)
                return jsonify({'data': data}), 200

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Queue/get_single.yml")
@app.route('/api/Queue/get_single', methods=['GET'])
def get_single_Queue():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                id = request.args.get('id')
                cursor = db_connection.cursor()
                sql = "SELECT * FROM queue WHERE id = ?;"
                cursor.execute(sql, (id,))
                row = cursor.fetchone()

                if row:
                    queue_dict = {
                        'queue_id': row[0],
                        'queue_name': row[1],
                        'group_id': row[2],
                        'comments': row[17]
                    }
                    return jsonify({'data': queue_dict}), 200
                else:
                    return jsonify({'error': 'Queue not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400
