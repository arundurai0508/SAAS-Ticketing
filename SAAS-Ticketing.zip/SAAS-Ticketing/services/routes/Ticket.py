
from flask import Flask, request, jsonify
from flasgger import Swagger, swag_from
from services import app
from config.config import DB_Connection
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader
from pyotrs import Client, Ticket, Article
from datetime import datetime
import re
from config.config import OTRS_URL


swagger_loc = app.config['SWAGGER_LOC']


UL = OTRS_URL.url
UN = OTRS_URL.username
PW = OTRS_URL.password

db_connection = DB_Connection()


class TicketConnector:
    def __init__(self, url, username, password):
        self.url = url
        self.username = username
        self.password = password
        self.client = Client(url, username, password)


ticket_connector = TicketConnector(UL, UN, PW)


@swag_from(swagger_loc + "/Ticket/create.yml")
@app.route('/api/ticket/create', methods=['POST'])
def create_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                if ticket_connector.client.session_create():
                    data = request.json

                    title = data.get('title')
                    queue = data.get('queue')
                    state = data.get('state')
                    priority = data.get('priority')
                    cus_user = data.get('cus_user')
                    subject = data.get('subject')
                    body = data.get('body')

                    new_ticket = Ticket.create_basic(
                        Title=title, Queue=queue, State=state, Priority=priority, CustomerUser=cus_user
                    )

                    first_article = Article({"Subject": subject, "Body": body})

                    result = ticket_connector.client.ticket_create(ticket=new_ticket, article=first_article)

                    return {"status": "success", "message": "Ticket created successfully", "Ticket Details": result}, 201

            except Exception as e:
                return {"status": "error", "message": f"An unexpected error occurred: {e}"}, 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/update.yml")
@app.route('/api/ticket/update', methods=['PUT'])
def update_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                data = request.get_json()
                ticket_id = data.get('id')
                title = data.get('title')
                queue = data.get('queue')
                priority = data.get('priority')
                state = data.get('state')


                if ticket_id is None:
                    return jsonify({"status": "error", "message": "Missing ticket_id:'ticket_id'"}), 400

                if not ticket_connector.client.session_create():
                    return jsonify({"status": "error", "message": "Failed to create a session. Please try again."}), 400

                result = ticket_connector.client.ticket_update(
                    ticket_id, Title=title, Queue=queue, State=state, Priority=priority,
                )

                return jsonify({"status": "success", "message": "Ticket updated successfully", "Ticket Details": result}), 200

            except Exception as e:
                return jsonify({"status": "error", "message": f"An unexpected error occurred: {e}"}), 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/Ticket/get_all.yml")
@app.route("/api/ticket/get_all", methods=["GET"])
def get_all_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                query = """
                       SELECT t.id,
                              t.tn,
                              t.title,
                              q.name AS queue_name,
                              u.login AS user_name,
                              tp.name AS priority_name,
                              ts.name AS state_name,
                              t.customer_user_id
                       FROM ticket t
                       LEFT JOIN ticket_priority tp ON t.ticket_priority_id = tp.id
                       LEFT JOIN ticket_state ts ON t.ticket_state_id = ts.id
                       LEFT JOIN queue q ON t.queue_id = q.id
                       LEFT JOIN users u ON t.user_id = u.id;
                   """
                cursor.execute(query)
                rows = cursor.fetchall()

                if not rows:
                    return jsonify({"status": "error", "message": "Ticket not found"}), 404

                data = []
                for row in rows:
                    ticket_dict = {
                        'ticket_id': row[0],
                        'ticket_number': row[1],
                        'title': row[2],
                        'queue': row[3],
                        'login_user': row[4],
                        'priority': row[5],
                        'state': row[6],
                        'customer_user': row[7]
                    }
                    data.append(ticket_dict)

                return jsonify({'number of tickets': len(data), 'ticket_data': data}), 200
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/Ticket/get_by_id.yml")
@app.route('/api/ticket/get_by_id', methods=['GET'])
def get_by_id_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                ticket_id = request.args.get('id')
                db_connection = DB_Connection()
                cursor = db_connection.cursor()

                query = """
                       SELECT t.id,
                              t.tn,
                              t.title,
                              q.name AS queue_name,
                              u.login AS user_name,
                              tp.name AS priority_name,
                              ts.name AS state_name,
                              t.customer_user_id
                       FROM ticket t
                       LEFT JOIN ticket_priority tp ON t.ticket_priority_id = tp.id
                       LEFT JOIN ticket_state ts ON t.ticket_state_id = ts.id
                       LEFT JOIN queue q ON t.queue_id = q.id
                       LEFT JOIN users u ON t.user_id = u.id
                       WHERE t.id = %s
                   """

                cursor.execute(query, (ticket_id,))
                rows = cursor.fetchall()

                if not ticket_id:
                    return jsonify({"status": "error", "message": "Ticket ID is missing"}), 400

                if not rows:
                    return jsonify({"status": "error", "message": "Ticket not found"}), 404

                data = []
                for row in rows:
                    ticket_dict = {
                        'ticket_id': row[0],
                        'ticket_number': row[1],
                        'title': row[2],
                        'queue': row[3],
                        'login_user': row[4],
                        'priority': row[5],
                        'state': row[6],
                        'customer_user': row[7]
                    }
                    data.append(ticket_dict)

                return jsonify({'ticket_data': data}), 200
            except Exception as e:
                return jsonify({"status": "error", "message": str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/Ticket/AgentUser_ticket_get_all.yml")
@app.route("/api/AgentUser/ticket/get_all", methods=["GET"])
def agent_user_fetch_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                agent_username = request.args.get('Agent_Username')

                db_connection = DB_Connection()
                cursor = db_connection.cursor()

                sql = "SELECT * FROM users WHERE login = ?;"
                cursor.execute(sql, (agent_username,))
                user_data = cursor.fetchone()
                if user_data:
                    base_query = """
                        SELECT t.id,
                               t.tn,
                               t.title,
                               q.name AS queue_name,
                               tp.name AS priority_name,
                               ts.name AS state_name,
                               t.customer_user_id
                        FROM ticket t
                        LEFT JOIN ticket_priority tp ON t.ticket_priority_id = tp.id
                        LEFT JOIN ticket_state ts ON t.ticket_state_id = ts.id
                        LEFT JOIN queue q ON t.queue_id = q.id
                        LEFT JOIN users u ON t.user_id = u.id
                    """

                    query = base_query + " WHERE u.login = %s"
                    cursor.execute(query, (agent_username,))

                    rows = cursor.fetchall()

                    if not rows:
                        return jsonify({"status": "error", "message": "Ticket not found"}), 404

                    data = []
                    for row in rows:
                        ticket_dict = {
                            'ticket_id': row[0],
                            'ticket_number': row[1],
                            'title': row[2],
                            'queue': row[3],
                            'priority': row[4],
                            'state': row[5],
                            'customer_user': row[6]
                        }
                        data.append(ticket_dict)

                    return jsonify({'number of tickets': len(data), 'ticket_data': data}), 200
                else:
                    return jsonify({'error': 'Agent user not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/Ticket/AgentUser_ticket_state_get_all.yml")
@app.route("/api/AgentUser/ticket/state/get_all", methods=["GET"])
def agent_user_state_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                agent_username = request.args.get('Agent_Username')
                state_name = request.args.get('state_name')

                db_connection = DB_Connection()
                cursor = db_connection.cursor()

                sql = "SELECT * FROM users WHERE login = ?;"
                cursor.execute(sql, (agent_username,))
                user_data = cursor.fetchone()
                if user_data:
                    sql = "SELECT * FROM ticket_state WHERE name = ?;"
                    cursor.execute(sql, (state_name,))
                    state_data = cursor.fetchone()
                    if state_data:
                        base_query = """
                            SELECT t.id,
                                   t.tn,
                                   t.title,
                                   q.name AS queue_name,
                                   tp.name AS priority_name,
                                   t.customer_user_id
                            FROM ticket t
                            LEFT JOIN ticket_priority tp ON t.ticket_priority_id = tp.id
                            LEFT JOIN ticket_state ts ON t.ticket_state_id = ts.id
                            LEFT JOIN queue q ON t.queue_id = q.id
                            LEFT JOIN users u ON t.user_id = u.id
                        """

                        query = base_query + " WHERE u.login = %s AND ts.name = %s"
                        cursor.execute(query, (agent_username, state_name))

                        rows = cursor.fetchall()

                        if not rows:
                            return jsonify({"status": "error", "message": "Ticket not found"}), 404

                        data = []
                        for row in rows:
                            ticket_dict = {
                                'ticket_id': row[0],
                                'ticket_number': row[1],
                                'title': row[2],
                                'queue': row[3],
                                'priority': row[4],
                                'customer_user': row[5]
                            }
                            data.append(ticket_dict)

                        return jsonify({'number of tickets': len(data), 'ticket_data': data}), 200
                    else:
                        return jsonify({'error': 'State not found'}), 404
                else:
                    return jsonify({'error': 'Agent user not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/Ticket/CustomerUser_ticket_get_all.yml")
@app.route("/api/CustomerUser/ticket/get_all", methods=["GET"])
def customer_user_fetch_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                customer_username = request.args.get('Customer_Username')

                db_connection = DB_Connection()
                cursor = db_connection.cursor()

                sql = "SELECT * FROM customer_user WHERE login = ?;"
                cursor.execute(sql, (customer_username,))
                user_data = cursor.fetchone()
                if user_data:

                    base_query = """
                                    SELECT t.id,
                                           t.tn,
                                           t.title,
                                           q.name AS queue_name,
                                           tp.name AS priority_name,
                                           ts.name AS state_name
                                    FROM ticket t
                                    LEFT JOIN ticket_priority tp ON t.ticket_priority_id = tp.id
                                    LEFT JOIN ticket_state ts ON t.ticket_state_id = ts.id
                                    LEFT JOIN queue q ON t.queue_id = q.id
                                    LEFT JOIN users u ON t.user_id = u.id
                                """

                    query = base_query + " WHERE t.customer_user_id = %s"
                    cursor.execute(query, (customer_username,))

                    rows = cursor.fetchall()

                    if not rows:
                        return jsonify({"status": "error", "message": "Ticket not found"}), 404

                    data = []
                    for row in rows:
                        ticket_dict = {
                            'ticket_id': row[0],
                            'ticket_number': row[1],
                            'title': row[2],
                            'queue': row[3],
                            'priority': row[4],
                            'state': row[5]
                        }
                        data.append(ticket_dict)

                    return jsonify({'number of tickets': len(data), 'ticket_data': data}), 200
                else:
                    return jsonify({'error': 'Customer user not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/Ticket/CustomerUser_ticket_state_get_all.yml")
@app.route("/api/CustomerUser/ticket/state/get_all", methods=["GET"])
def customer_user_state_ticket():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                customer_username = request.args.get('Customer_Username')
                state_name = request.args.get('state_name')

                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                sql = "SELECT * FROM customer_user WHERE login = ?;"
                cursor.execute(sql, (customer_username,))
                user_data = cursor.fetchone()
                if user_data:
                    sql = "SELECT * FROM ticket_state WHERE name = ?;"
                    cursor.execute(sql, (state_name,))
                    state_data = cursor.fetchone()
                    if state_data:

                        base_query = """
                                        SELECT t.id,
                                               t.tn,
                                               t.title,
                                               q.name AS queue_name,
                                               tp.name AS priority_name
                                        FROM ticket t
                                        LEFT JOIN ticket_priority tp ON t.ticket_priority_id = tp.id
                                        LEFT JOIN ticket_state ts ON t.ticket_state_id = ts.id
                                        LEFT JOIN queue q ON t.queue_id = q.id
                                        LEFT JOIN users u ON t.user_id = u.id
                                    """

                        query = base_query + " WHERE t.customer_user_id = %s AND ts.name = %s"
                        cursor.execute(query, (customer_username, state_name))

                        rows = cursor.fetchall()

                        if not rows:
                            return jsonify({"status": "error", "message": "Ticket not found"}), 404

                        data = []
                        for row in rows:
                            ticket_dict = {
                                'ticket_id': row[0],
                                'ticket_number': row[1],
                                'title': row[2],
                                'queue': row[3],
                                'priority': row[4]
                            }
                            data.append(ticket_dict)

                        return jsonify({'number of tickets': len(data), 'ticket_data': data}), 200
                    else:
                        return jsonify({'error': 'State not found'}), 404
                else:
                    return jsonify({'error': 'Customer user not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400
