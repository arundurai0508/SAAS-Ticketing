from flask import Flask, request, jsonify
from datetime import datetime
import re
from services import app
from config.config import DB_Connection
from flasgger import Swagger, swag_from
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader

swagger_loc = app.config['SWAGGER_LOC']


def sanitize_name(character):
    return re.sub(r'[+\-*/!#$%^&|_<?{}>0123456789]', '', character)


@swag_from(swagger_loc + "/CustomerID/create.yml")
@app.route('/api/CustomerID/create', methods=['POST'])
def create_CustomerID():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                customer_id = data.get('customer_id')
                name = data.get('name')
                comments = data.get('comments')
                valid_id = 1
                login_user = data.get('login_user')
                current_time = datetime.now()

                if not all([customer_id, name, comments, valid_id, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_name = sanitize_name(name)
                sanitized_comments = sanitize_name(comments)

                if name != sanitized_name or comments != sanitized_comments:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = """INSERT INTO customer_company (name, customer_id, comments, valid_id, create_time, create_by, change_time, change_by) 
                         VALUES (%s, %s, %s, %s, %s, %s, %s, %s);"""
                cursor.execute(sql, (name, customer_id, comments, valid_id, current_time, login_name, current_time, login_name))

                db_connection.commit()

                return jsonify({'message': 'CustomerID created successfully'}), 201

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/CustomerID/update.yml")
@app.route('/api/CustomerID/update', methods=['PUT'])
def update_CustomerID():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                customer_id = data.get('customer_id')
                name = data.get('name')
                comments = data.get('comments')
                valid_id = data.get('valid_id')
                login_user = data.get('login_user')

                current_time = datetime.now()

                if not all([customer_id, name, comments, valid_id, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_name = sanitize_name(name)
                sanitized_comments = sanitize_name(comments)

                if name != sanitized_name or comments != sanitized_comments:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = "SELECT * FROM customer_company WHERE customer_id = ?"
                cursor.execute(sql, (customer_id,))
                data = cursor.fetchone()
                if data:

                    valid_query = (f'SELECT id FROM valid where name = "{valid_id}";')
                    cursor.execute(valid_query, )
                    valid_row = cursor.fetchone()
                    if not valid_row:
                        return jsonify({"error": "Valid ID not found"}), 404
                    valid = valid_row[0]

                    sql = """UPDATE customer_company SET name = %s, comments = %s, valid_id = %s, change_time = %s, change_by = %s WHERE customer_id = %s;"""

                    cursor.execute(sql, (name, comments, valid, current_time, login_name, customer_id))

                    db_connection.commit()

                    return jsonify({'message': 'CustomerID updated successfully'}), 200
                else:
                    return jsonify({'error': 'CustomerID not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/CustomerID/get_all.yml")
@app.route('/api/CustomerID/get_all', methods=['GET'])
def get_all_CustomerID():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                sql = "SELECT * FROM customer_company"
                cursor.execute(sql)
                data = []
                for row in cursor.fetchall():
                    CustomerID_dict = {
                        'customer_id': row[0],
                        'name': row[1],
                        'comments': row[7]
                    }
                    data.append(CustomerID_dict)
                return jsonify({'data': data}), 200

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/CustomerID/get_single.yml")
@app.route('/api/CustomerID/get_single', methods=['GET'])
def get_single_CustomerID():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                id = request.args.get('id')
                cursor = db_connection.cursor()
                sql = "SELECT * FROM customer_company WHERE customer_id = ?;"
                cursor.execute(sql, (id,))
                row = cursor.fetchone()

                if row:
                    CustomerID_dict = {
                        'customer_id': row[0],
                        'name': row[1],
                        'comments': row[7]
                    }
                    return jsonify({'data': CustomerID_dict}), 200
                else:
                    return jsonify({'error': 'CustomerID not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


