from flask import Flask, request, jsonify
from datetime import datetime
import re
from services import app
from config.config import DB_Connection
from flasgger import Swagger, swag_from
import hashlib
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader

swagger_loc = app.config['SWAGGER_LOC']


def sanitize_name(character):
    return re.sub(r'[+\-*/!#$%^&|<?{}>0123456789]', '', character)

def hash_password_sha256(password):
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    return hashed_password


@swag_from(swagger_loc + "/CustomerUser/create.yml")
@app.route('/api/CustomerUser/create', methods=['POST'])
def create_CustomerUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                username = data.get('username')
                email = data.get('email')
                customer_id = data.get('customer_id')
                password = data.get('password')
                first_name = data.get('first_name')
                last_name = data.get('last_name')
                valid_id = 1
                login_user = data.get('login_user')
                current_time = datetime.now()

                if not all([username, email, customer_id, password, first_name, last_name, valid_id, login_user]):
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_username = sanitize_name(username)
                sanitized_first_name = sanitize_name(first_name)
                sanitized_last_name = sanitize_name(last_name)

                if username != sanitized_username or first_name != sanitized_first_name or last_name != sanitized_last_name:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()
                hashed_password = hash_password_sha256(password)

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                customerID_query = (f'SELECT customer_id FROM customer_company where name = "{customer_id}";')
                cursor.execute(customerID_query, )
                customerID_row = cursor.fetchone()
                if not customerID_row:
                    return jsonify({"error": "Customer ID not found"}), 404
                customerID = customerID_row[0]

                sql = """INSERT INTO customer_user (login, email, customer_id, pw, first_name, last_name, valid_id,
                    create_time, create_by, change_time, change_by) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"""

                cursor.execute(sql, (
                username, email, customerID, hashed_password, first_name, last_name, valid_id, current_time, login_name, current_time, login_name))
                db_connection.commit()

                return jsonify({'message': 'Customer user created successfully'}), 201

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/CustomerUser/update.yml")
@app.route('/api/CustomerUser/update', methods=['PUT'])
def update_CustomerUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                id = data.get('id')
                username = data.get('username')
                email = data.get('email')
                customer_id = data.get('customer_id')
                password = data.get('password')
                first_name = data.get('first_name')
                last_name = data.get('last_name')
                valid_id = data.get('valid_id')
                login_user = data.get('login_user')

                current_time = datetime.now()

                if not username or not email or not customer_id or not password or not first_name or not last_name or not valid_id or not login_user:
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_username = sanitize_name(username)
                sanitized_first_name = sanitize_name(first_name)
                sanitized_last_name = sanitize_name(last_name)

                if username != sanitized_username or first_name != sanitized_first_name or last_name != sanitized_last_name:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()
                hashed_password = hash_password_sha256(password)

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = "SELECT * FROM customer_user WHERE id = ?"
                cursor.execute(sql, (id,))
                data = cursor.fetchone()
                if data:

                    valid_query = (f'SELECT id FROM valid where name = "{valid_id}";')
                    cursor.execute(valid_query, )
                    valid_row = cursor.fetchone()
                    if not valid_row:
                        return jsonify({"error": "Valid ID not found"}), 404
                    valid = valid_row[0]

                    customerID_query = (f'SELECT customer_id FROM customer_company where name = "{customer_id}";')
                    cursor.execute(customerID_query, )
                    customerID_row = cursor.fetchone()
                    if not customerID_row:
                        return jsonify({"error": "Customer ID not found"}), 404
                    customerID = customerID_row[0]

                    sql = """UPDATE customer_user SET  login = %s, email = %s, customer_id = %s, pw = %s, first_name = %s,
                    last_name = %s, valid_id = %s, change_time = %s, change_by = %s WHERE id = %s;"""

                    cursor.execute(sql, (
                    username, email, customerID, hashed_password, first_name, last_name, valid, current_time, login_name, id))

                    db_connection.commit()

                    return jsonify({'message': 'Customer user updated successfully'}), 200
                else:
                    return jsonify({'error': 'Customer user not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/CustomerUser/get_all.yml")
@app.route('/api/CustomerUser/get_all', methods=['GET'])
def get_all_CustomerUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                sql = "SELECT * FROM customer_user"
                cursor.execute(sql)
                data = []
                for row in cursor.fetchall():
                    user_dict = {
                        'user_ID': row[0],
                        'username': row[1],
                        'email': row[2],
                        'customer_ID': row[3],
                        'name': f"{row[6]} {row[7]}"
                    }
                    data.append(user_dict)
                return jsonify({'data': data}), 200

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/CustomerUser/get_single.yml")
@app.route('/api/CustomerUser/get_single', methods=['GET'])
def get_single_CustomerUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                id = request.args.get('id')
                cursor = db_connection.cursor()
                sql = "SELECT * FROM customer_user WHERE id = ?;"
                cursor.execute(sql, (id,))
                row = cursor.fetchone()

                if row:
                    user_dict = {
                        'user_ID': row[0],
                        'username': row[1],
                        'email': row[2],
                        'customer_ID': row[3],
                        'name': f"{row[6]} {row[7]}"
                    }
                    return jsonify({'data': user_dict}), 200
                else:
                    return jsonify({'error': 'Customer user not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


