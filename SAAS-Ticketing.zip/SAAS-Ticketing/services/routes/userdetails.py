
import json
import re
import dns.resolver
import smtplib
import socket

import sqlalchemy.orm
from flask import Flask, request, jsonify, redirect, url_for, render_template
from functools import wraps
import smtplib
from sqlalchemy import and_
import re
import requests
from services import db
from flask_cors import CORS
from services.utils import ConnMQ as mq, sessionkeygen
from flasgger import swag_from
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from datetime import datetime, timedelta
from services import app
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader
from services.models.models import User, Tenant, Nano, Role, UserRole, SubscriptionType, \
    TimeZone, RoleTabPermission as RTP, Permission, Tab, Session, Temp_User, Region, Languages
from email.message import EmailMessage
import random
import string

CORS(app)
secret = app.config['SECRET']
baseurl = app.config['BASEURL']
verify_url = app.config['EMAIL_VERIFICATION_URL']
swagger_loc = app.config['SWAGGER_LOC']
smtp_username = app.config['SMTP_USERNAME']
smtp_password = app.config['SMTP_PASSWORD']


def is_business_email(email):
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    if not re.match(email_regex, email):
        return False

    _, domain = email.split('@')

    business_email_providers = ['yahoo.com', 'outlook.com', 'hotmail.com', 'aol.com', 'icloud.com',
                                'protonmail.com']  # Add more business email domains here

    if domain.lower() in business_email_providers:
        return False

    return (domain.split('.'))[0]


def verify_recaptcha(response):
    # Replace 'YOUR_RECAPTCHA_SECRET_KEY' with your actual reCAPTCHA secret key
    secret_key = 'YOUR_RECAPTCHA_SECRET_KEY'

    # Make a POST request to the Google reCAPTCHA verification endpoint
    response = requests.post('https://www.google.com/recaptcha/api/siteverify',
                             data={'secret': secret_key, 'response': response})

    # Parse the JSON response
    result = response.json()

    # Check if reCAPTCHA verification was successful
    if result['success']:
        return True
    else:
        return False


def send_verification_email(email, otp):
    sender_email = 'tharwinn1997@gmail.com'
    # message = MIMEText(f'Click the following link to generate your password: {verification_link}')
    message = EmailMessage()
    message['Subject'] = 'Activate Autointelli Account'
    message['From'] = sender_email
    message['To'] = email
    message.set_content('''
        <!DOCTYPE html>
        <html>
        <head>
            <link rel="stylesheet" type="text/css" hs-webfonts="true" href="https://fonts.googleapis.com/css?family=Lato|Lato:i,b,bi">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style type="text/css">
              h1{font-size:56px}
              h2{font-size:28px;font-weight:900}
              p{font-weight:100}
              td{vertical-align:top}
              .btn{ border: none;
                      color: white;
                       background-color: #0F629E;
                      padding: 15px 32px;
                      text-align: center;
                      text-decoration: none;
                      display: inline-block;
                      font-size: 16px;
                      margin: 4px 2px;
                      cursor: pointer;}
              #email{margin:auto;width:600px;background-color:#fff}
            </style>
        </head>
        <body bgcolor="#B3B6B7" style="width: 100%; font-family:Lato, sans-serif; font-size:18px;">
        <div id="email">

            <table role="presentation" width="100%" bgcolor="#B3B6B7" >
                <tr>
                    <td bgcolor="#154360" align="center" width="50%" style="color: white;">
                        <h1> Autointelli</h1>
                    </td>
                </tr>

                <tr align="center" bgcolor="white">
                    <td style="color: black;">
                        <h4 >Verify your email address</h4>
                        <h8 style="font-size:15px;color: black;">
                            Thanks for starting the new Autointelli account creation process.We want to make sure it's really you. Please enter the following verification code when prompted. If you don’t want to create an account, you can ignore this message.
                            </h8>
             	
				
				<h5  style="color: black;line-height: 0.2;">verification code</h5>
                            <h2 style="line-height: 1.2;">''' + otp + '''</h2>
				<h8  style="color: black;line-height: 1.2;">(This code is valid for 10 minutes)</h8>

              

                <tr bgcolor="white">
                    <td bgcolor="white" align="center" width="50%" style="color: black;">
                        <p style="font-size:12px;">Autointelli Web Services will never email you and ask you to disclose or verify your password, credit card, or banking account number.</p>

                    </td>
                </tr>
            </table>

        </div>
        </body>
        </html>
    ''', subtype='html')

    try:
        smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
        smtp_server.starttls()
        smtp_server.login(smtp_username, smtp_password)  # Change to your password
        smtp_server.sendmail(sender_email, [email], message.as_string())
        smtp_server.quit()
        return True
    except Exception as e:
        print(f"Email sending failed: {e}")
        return False


def send_user_verification_email(email, verification_link):
    sender_email = 'tharwinn1997@gmail.com'
    # message = MIMEText(f'Click the following link to generate your password: {verification_link}')
    message = EmailMessage()
    message['Subject'] = 'Activate Autointelli Account'
    message['From'] = sender_email
    message['To'] = email
    message.set_content('''
       <!DOCTYPE html>
    <html lang="en">
    <head>
        <link rel="stylesheet" type="text/css" hs-webfonts="true" href="https://fonts.googleapis.com/css?family=Lato|Lato:i,b,bi">
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style type="text/css">
    			     .logoimage{
                    width: 150px;
                    }
                    button{
                    background-color:black;
                    color: white;
                    width: 100px;
                    height: 35px;
                    }
                    
                    .btn{
                    background-color:black;
                    text-decoration: none;
                    color: white;
                    cursor: pointer;
                    }
                  
                </style>
    </head>
    <body>
        <div id="email">
                <div>
                        <img class="logoimage" alt="Autointelli_logo" src="https://www.autointelli.com/assets/img/Logo.png" />
                    </div>
                    <div>
                        <h2>Hello,</h2>
                    </div>
                    <div>
                        <p style="color: grey;">Welcome! We received a request regarding your account. Please verify your email address to continue.</p>
                    </div>
                    <div>
                     <button><a class="btn" href=''' + verification_link + ''' target="_blank">Verify Email</a></button>
                    </div>
                    <div>
                        <p style="color: grey;">By verifying, you agree with our Terms of Service and Services Privacy Notice</p>
                    </div>
                    <div>
                        <p style="color: grey;">Thank you!</p>
                        <p style="color: grey;">Sincerely,</p>
                        <p style="color: grey;">The Autointelli Team</p>
                    </div>
            </div>
            </body>
    </body>
</html>

    ''', subtype='html')

    try:
        smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
        smtp_server.starttls()
        smtp_server.login(smtp_username, smtp_password)  # Change to your password
        smtp_server.sendmail(sender_email, [email], message.as_string())
        smtp_server.quit()
        return True
    except Exception as e:
        print(f"Email sending failed: {e}")
        return False


def forgot_password_email(email, otp):
    sender_email = 'tharwinn1997@gmail.com'
    # message = MIMEText(f'Click the following link to generate your password: {verification_link}')
    message = EmailMessage()
    message['Subject'] = 'Reset Password'
    message['From'] = sender_email
    message['To'] = email
    message.set_content('''
        <!DOCTYPE html>
        <html>
        <head>
            <link rel="stylesheet" type="text/css" hs-webfonts="true" href="https://fonts.googleapis.com/css?family=Lato|Lato:i,b,bi">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style type="text/css">
              h1{font-size:56px}
              h2{font-size:28px;font-weight:900}
              p{font-weight:100}
              td{vertical-align:top}
              .btn{ border: none;
                      color: white;
                       background-color: #0F629E;
                      padding: 13px 32px;
                      text-align: center;
                      text-decoration: none;
                      display: inline-block;
                      font-size: 16px;
                      margin: 4px 2px;
                      cursor: pointer;}
              #email{margin:auto;width:600px;background-color:#fff}
            </style>
        </head>
        <body bgcolor="#B3B6B7" style="width: 100%; font-family:Lato, sans-serif; font-size:18px;">
        <div id="email">

            <table role="presentation" width="100%" bgcolor="#B3B6B7" >
                <tr style="height: 20px;">
                    <td bgcolor="#154360" align="center" width="50%" style="color: white;">
                        <h1> Autointelli</h1>
                    </td>
                </tr>

                <tr align="center" bgcolor="white">
                    <td style="color: black";>
                        <h4 >Reset Password</h4>
                        <p style="font-size:15px;">
                            Please click the below button to reset your password. If you are not requested this, you can ignore this message.
                            <h5  style="color: black;line-height: 0.2;">verification code</h5>
                            <h2 style="line-height: 1.2;">''' + otp + '''</h2>
				            <h8  style="color: black;line-height: 1.2;">(This code is valid for 10 minutes)</h8>

              

                        </p>
                    </td>
                </tr>

                <tr bgcolor="white">
                    <td bgcolor="white" align="center" width="50%" style="color: black;">
                        <p style="font-size:12px;">Autointelli Web Services will never email you and ask you to disclose or verify your password, credit card, or banking account number.</p>

                    </td>
                </tr>
            </table>

        </div>
        </body>
        </html>
    ''', subtype='html')

    try:
        smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
        smtp_server.starttls()
        smtp_server.login(smtp_username, smtp_password)  # Change to your password
        smtp_server.sendmail(sender_email, [email], message.as_string())
        smtp_server.quit()
        return True
    except Exception as e:
        print(f"Email sending failed: {e}")
        return False


@swag_from(swagger_loc + "/Users/register.yml")
@app.route(baseurl + 'register', methods=['POST'])
def register(*args):
    data = request.get_json()
    BusinessName = data['Business_name']
    Email = data['Email']
    if not BusinessName or not Email:
        return jsonify({'error': 'Missing company name or email'}), 400
    user = User.query.filter_by(email=Email).first()
    if user:
        return jsonify({'error': 'User with this email already exists'}), 400
    if Tenant.query.filter_by(businessname=BusinessName).first():
        return jsonify({'error': 'User with this Businessname already exists'}), 400

    domain = is_business_email(Email)
    if not domain:
        return jsonify({'error': 'Only business emails are allowed'}), 400

    otp = ''.join(random.choices('0123456789', k=6))

    if not send_verification_email(Email, otp):
        return jsonify({"message": "Failed to send verification email", "type": "failure"}), 400

    new_user = Temp_User(
        email=Email,
        otp=otp,
        businessname=BusinessName,
        creationtime=datetime.now()
    )
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'Verification sent successfully', 'otp': otp,
                    'url': f'verify_code'}), 302


@app.route(baseurl + 'verify_code', methods=['PUT'])
@swag_from(swagger_loc + "/Users/verify_code.yml")
def verify_code(*args):
    try:
        data = request.get_json()
        otp = data['OTP']
        data = Temp_User.query.filter_by(otp=otp).first()
        if data:
            creation_time = data.creationtime
            if datetime.now() - creation_time <= timedelta(minutes=10):
                data.otp = None
                data.creationtime = None
                db.session.add(data)
                db.session.commit()
                return jsonify({'message': f'OTP verified successfully.',
                                "url": f'http://localhost:3000/create_password?id={data.tempuserid}'}), 302
            else:
                return jsonify({'message': 'OTP expired. Please request a new OTP.'}), 401
        else:
            return jsonify({'message': 'Invalid OTP. Please request a new OTP.'}), 401

    except Exception as e:
        # Log the exception and return error response
        print(e)
        return jsonify({'message': 'Try Again !!! Something Went Wrong!!!', 'type': 'failure'}), 404


@app.route(baseurl + 'create_password', methods=['POST'])
@swag_from(swagger_loc + "/Users/create_password.yml")
def create_password():
    try:
        # Extract data from request
        d = request.get_json()
        id = d['id']
        password = d['Password']
        try:
            # Insert organization dat
            data = Temp_User.query.filter_by(tempuserid=id).first()

            subs = SubscriptionType.query.filter_by(typename="Free").first()

            tenant = Tenant(
                businessname=data.businessname,
                subscriptiontypeid=subs.subscriptiontypeid
            )
            db.session.add(tenant)
            db.session.commit()
            user = User(
                email=data.email,
                attempts=0,
                activeyn='y',
                password=generate_password_hash(password),
                firsttimelogin='y',
                tenantid=tenant.tenantid
            )

            db.session.add(user)
            db.session.commit()
            role = Role.query.filter_by(rolename='Admin').first()
            if role:
                new_user_role = UserRole(
                    userid=user.userid,
                    roleid=role.roleid
                )
                db.session.add(new_user_role)
                db.session.commit()
            else:
                raise Exception("Role not found")

            # Return success response
            return jsonify({'id': user.userid, 'message': 'Password generation success', 'type': 'success'}), 200

        except Exception as e:
            # Rollback transaction and return error response
            db.session.rollback()
            print(e)
            return jsonify({'message': 'Try Again !!! Something Went Wrong!!!', 'type': 'failure'}), 404

    except Exception as e:
        # Log the exception and return error response
        print(e)
        return jsonify({'message': 'Try Again !!! Something Went Wrong!!!', 'type': 'failure'}), 404


@app.route(baseurl + 'select_region', methods=['POST'])
@swag_from(swagger_loc + "/Users/select_regions.yml")
def select_region():
    try:
        data = request.get_json()
        id = data.get('id')
        language = data['Language']
        Zone = data['TimeZone']
        region = data.get('region')
        if not id or not region or not language or not TimeZone:
            return jsonify({'error': 'Missing id or region'}), 400

        user = User.query.filter_by(userid=id).first()
        if user:
            tenant = Tenant.query.filter_by(tenantid=user.tenantid).first()
            if tenant.customeruniqueid:
                return jsonify({"type": "failure", "message": "Alredy Region selected!!!"}), 400
            nano = Nano.query.filter_by(status='inactive').first()
            nano_id = nano.nano_id
            reg = Region.query.filter_by(region=region).first()
            tenant.regionid = reg.regionid
            tenant.customeruniqueid = nano_id
            nano.status = "active"
            lag = Languages.query.filter_by(language=language).first()
            user.language = lag.languageid
            zone = TimeZone.query.filter_by(timezone=Zone).first()
            user.timezoneid = zone.zoneid
            db.session.add(tenant)
            db.session.commit()
            db.session.add(nano)
            db.session.commit()
            db.session.add(user)
            db.session.commit()
            mq_nano = ''.join(random.choice(string.ascii_lowercase) for _ in range(6))
            mq_result = mq.send2MQ("Ticketing", "saas", "Ticketing", {"nano_id": mq_nano})
            if mq_result['result'] == 'success':
                new_nano = Nano(nano_id=mq_nano, status="inactive")
                db.session.add(new_nano)
                db.session.commit()
                return jsonify({"message": "Region selected successfully", "type": "success", "nano_id": nano_id}), 200

        else:
            return jsonify({"message": f"User not found", "type": "failure"}), 404
    except Exception as e:
        print(e)
        return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400


@app.route(baseurl + 'login', methods=['POST'])
@swag_from(swagger_loc + "/Users/login.yml")
def login():
    try:

        data = request.get_json()
        Email = data.get('email')
        password = data.get('password')
        user = User.query.filter_by(email=Email).first()
        if not user:
            return jsonify({"type": "failure", "message": "User not found"}), 404

        if not check_password_hash(user.password, password):
            user.attempts += 1
            db.session.commit()

            if user.attempts >= app.config['MAX_LOGIN_ATTEMPTS']:
                user.lockout_time = datetime.utcnow() + app.config['LOCKOUT_DURATION']
                user.attempts = 0
                db.session.add(user)
                db.session.commit()
                return jsonify({
                                   "error": f"Maximum login attempts reached. User locked out for {app.config['LOCKOUT_DURATION']}."}), 401
            else:
                return jsonify({"error": "Incorrect password"}), 401
        tenant = Tenant.query.filter_by(tenantid=user.tenantid).first()
        if not tenant.regionid:
            url = f"http://localhost:3000/Select_Region/{user.userid}"
            return jsonify({"url": url}), 302

        key = sessionkeygen.createSession(user.userid)
        if key['result'] == 'success':
            k = key['data']
        else:
            return key
        role = UserRole.query.filter_by(userid=user.userid).first().roleid

        rm = RTP.query.filter(
            and_(
                RTP.roleid == role,
                RTP.permissionid == Permission.permissionid,
                RTP.tabid == Tab.tabid

            )
        ).all()
        data = {}
        for i in rm:
            r = RTP.query.filter_by(rolepermissionid=i.rolepermissionid).first()
            t = Tab.query.filter_by(tabid=r.tabid).first()
            p = Permission.query.filter_by(permissionid=r.permissionid).first()
            data[t.tabname] = p.permissionname

        data = {"id": user.userid, "mapper": data, "session": k}
        user.attempts = 0
        db.session.add(user)
        db.session.commit()
        return jsonify({"type": "success", "message": "Login successful", "data": data}), 200
    except Exception as e:
        print(e)
        return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400


@app.route(baseurl + 'forgot_password', methods=['POST'])
@swag_from(swagger_loc + "/Users/forgot_password.yml")
def forgot_password(*args):
    try:
        data = request.get_json()
        Email = data['email']
        if not Email:
            return jsonify({'error': 'Missing email'}), 400

        user = User.query.filter_by(email=Email).first()

        if not user:
            return jsonify({'error': 'User not found'}), 400

        otp = ''.join(random.choices('0123456789', k=6))
        user.otp = otp
        user.otpcreationtime = datetime.now()
        db.session.add(user)
        db.session.commit()
        if not forgot_password_email(Email, otp):
            return jsonify({"message": "Failed to send OTP", "type": "failure"}), 400
        return jsonify({'message': 'OTP sent successfully', 'otp': otp}), 200
    except Exception as e:
        print(e)
        return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400


@app.route(baseurl + 'verify_user_code', methods=['PUT'])
@swag_from(swagger_loc + "/Users/verify_user.yml")
def verify_user_code(*args):
    try:
        otp = request.get_json()['OTP']
        data = User.query.filter_by(otp=otp).first()
        if data:
            creation_time = data.otpcreationtime
            if datetime.now() - creation_time <= timedelta(minutes=10):
                data.otp = None
                data.otpcreationtime = None
                db.session.add(data)
                db.session.commit()
                return jsonify({'message': f'OTP verified successfully.', 'id': data.userid,
                                "url": f'http://localhost:3000/reset_password?id={data.userid}'}), 302
            else:
                return jsonify({'message': 'OTP expired. Please request a new OTP.'}), 401
        else:
            return jsonify({'message': 'Invalid OTP. Please request a new OTP.'}), 401

    except Exception as e:
        print(e)
        return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400


@app.route(baseurl + 'reset_password', methods=['POST'])
@swag_from(swagger_loc + "/Users/reset_password.yml")
def reset_password(*args):
    try:
        id = request.get_json()['id']
        password = request.get_json()['password']
        hashed_password = generate_password_hash(password)
        user = User.query.filter_by(userid=id).first()
        if not id:
            return jsonify({"type": "failure", "message": "id required"}), 400
        if not user:
            return jsonify({'message': 'Invalid OTP. Please request a new OTP.'}), 401
        if not password:
            return jsonify({"type": "failure", "message": "password required"}), 400
        user.password = hashed_password
        db.session.add(user)
        db.session.commit()
        return jsonify({'message': 'Password reset successful!!!', "type": "success"}), 200
    except Exception as e:
        print(e)
        return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400


@app.route(baseurl + 'adduser', methods=['POST'])
@swag_from(swagger_loc + "/Users/add_user.yml")
def add_user(*args):
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                data = request.get_json()
                Email = data.get('email')
                RoleName = data.get('role')
                session = Session.query.filter_by(sessionkeys=request.headers["SESSIONKEY"]).first()
                user = User.query.filter_by(userid=session.userid).first()

                domain = is_business_email(Email)
                if not domain:
                    return jsonify({'error': 'Only business emails are allowed'}), 400
                exist_user = User.query.filter_by(email=Email).first()
                if exist_user:
                    return jsonify({'error': 'User with this email already exists'}), 400
                new_user = User(
                    email=Email,
                    tenantid=user.tenantid,
                    language=user.language,
                    createdate=datetime.utcnow(),
                    timezoneid=user.timezoneid,
                    firsttimelogin='y',
                    activeyn='y'
                )
                db.session.add(new_user)
                db.session.commit()
                role = Role.query.filter_by(rolename=RoleName).first()
                new_userrole = UserRole(
                    userid=new_user.userid,
                    roleid=role.roleid
                )
                db.session.add(new_userrole)
                db.session.commit()

                url = verify_url + f'/set_password?id={new_user.userid}'

                if not send_user_verification_email(Email, url):
                    return jsonify({"message": "Failed to send verification email", "type": "failure"}), 400

                return jsonify({'id': new_user.userid, 'message': 'User added successful!!!', "type": "success"}), 200
            except Exception as e:
                print(e)
                db.session.rollback()
                return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@app.route(baseurl + 'set_password', methods=['POST'])
@swag_from(swagger_loc + "/Users/set_password.yml")
def set_password(*args):
    try:
        data = request.get_json()
        password = data.get('password')
        hashed_password = generate_password_hash(password)
        id = data.get('id')
        user = User.query.filter_by(userid=id).first()
        if not user:
            return jsonify({"message": f"User not found", "type": "failure"}), 404
        user.password = hashed_password
        db.session.add(user)
        db.session.commit()
        return jsonify({'message': 'Password created successful!!!', "type": "success"}), 200

    except Exception as e:
        db.session.rollback()
        print(e)
        return jsonify({"message": "Something Went Wrong!!!", "type": "failure"}), 400


@swag_from(swagger_loc+"/Users/logout.yml")
@app.route(baseurl+'logout', methods=['PUT'])
def logout():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                key = request.headers["SESSIONKEY"]
                sessionupdate=Session.query.filter(Session.sessionkeys==key.strip()).first()
                sessionupdate.activeyn="N"
                db.session.add(sessionupdate)
                db.session.commit()
                user=User.query.filter_by(userid=sessionupdate.userid).first()
                user.lastactive=datetime.utcnow()
                db.session.add(user)
                db.session.commit()
                return json.dumps({"result": "success", "data": "Successfully logged out"})

            except :

                return json.dumps({'result': 'failure', "message": "Unable to logout."})
        else:
                return {"result": "failure", "data": "invalid api-key"}, 400
    else:
            return {"result": "failure", "data": "api-key missing"}, 400


@app.route(baseurl + 'getall_timezone', methods=['GET'])
def getAll_Timezone():
    time_zones = db.session.query(TimeZone).all()
    time_zone_list = [tz.timezone for tz in time_zones]

    return jsonify({'data': time_zone_list, 'type': 'success'}), 200


@app.route(baseurl + 'getall_language', methods=['GET'])
def getAll_language():
    lang = db.session.query(Languages).all()
    lang_list = [l.language for l in lang]

    return jsonify({'data': lang_list, 'type': 'success'}), 200


@app.route(baseurl + 'getall_region', methods=['GET'])
def getAll_region():
    regions = db.session.query(Region).all()
    region_list = [l.region for l in regions]

    return jsonify({'data': region_list, 'type': 'success'}), 200
