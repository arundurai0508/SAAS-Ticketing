from flask import Flask, request, jsonify
from datetime import datetime
import random, secrets, time
from config.config import DB_Connection

app = Flask(__name__)

def generate_ticket_number():
    now = datetime.now()
    timestamp = now.strftime("%Y%m%d%H%M%S")
    unique_part = now.strftime("%f")[:2]
    token_number = f"{timestamp}{unique_part}"
    return token_number

def current_unix_timestamp():
    return int(datetime.now().timestamp())

def insert_fingerprint_article():
    number_part = str(random.randint(100000, 999999))
    string_part = secrets.token_urlsafe(24)
    insert_fingerprint = f"{number_part}-{string_part}"
    return insert_fingerprint

def generate_timestamp():
    return int(time.time())

@app.route('/api/ticket/create', methods=['POST'])
def create_ticket():
    try:
        db_connection = DB_Connection()
        cursor = db_connection.cursor()

        data = request.get_json()
        title = data.get('title')
        queue = data.get('queue')
        priority = data.get('priority')
        state = data.get('state')
        user_name = data.get('user_name')
        customer_user_name = data.get('customer_user_name')
        login_user = data.get('login_user')
        subject = data.get('subject')
        body = data.get('body')

        ticket_lock_id = 1
        responsible_user_id = 1
        until_time = 0
        escalation_time = 0
        escalation_update_time = 0
        escalation_response_time = 0
        escalation_solution_time = 0
        archive_flag = 0

        ticket_number = generate_ticket_number()
        timeout = current_unix_timestamp()
        current_time = datetime.now()

        cursor.execute('SELECT id FROM users WHERE login = %s', (login_user,))
        login_row = cursor.fetchone()
        if not login_row:
            return jsonify({"error": "Login Username not found"}), 404
        login_name = login_row[0]

        cursor.execute('SELECT id FROM users WHERE login = %s', (user_name,))
        user_row = cursor.fetchone()
        if not user_row:
            return jsonify({"error": "User name not found"}), 404
        users_name = user_row[0]

        cursor.execute('SELECT id FROM queue WHERE name = %s', (queue,))
        queue_row = cursor.fetchone()
        if not queue_row:
            return jsonify({"error": "Queue not found"}), 404
        queue_name = queue_row[0]

        cursor.execute('SELECT id FROM ticket_priority WHERE name = %s', (priority,))
        priority_row = cursor.fetchone()
        if not priority_row:
            return jsonify({"error": "Priority not found"}), 404
        priority_name = priority_row[0]

        cursor.execute('SELECT id FROM ticket_state WHERE name = %s', (state,))
        state_row = cursor.fetchone()
        if not state_row:
            return jsonify({"error": "State not found"}), 404
        state_name = state_row[0]

        sql = """INSERT INTO ticket
                 (tn, title, queue_id, ticket_lock_id, user_id, responsible_user_id,
                  ticket_priority_id, ticket_state_id, customer_user_id, timeout, until_time,
                  escalation_time, escalation_update_time, escalation_response_time, escalation_solution_time,
                  archive_flag, create_time, create_by, change_time, change_by)
                 VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
        cursor.execute(sql, (
            ticket_number, title, queue_name, ticket_lock_id, users_name, responsible_user_id,
            priority_name, state_name, customer_user_name, timeout, until_time, escalation_time, escalation_update_time,
            escalation_response_time, escalation_solution_time, archive_flag, current_time, login_name, current_time, login_name
        ))

        ticket_id = cursor.lastrowid

        insert_fingerprint = insert_fingerprint_article()
        article_sender_type_id = 1
        communication_channel_id = 3
        is_visible_for_customer = 1
        search_index_needs_rebuild = 0

        sql2 = """INSERT INTO article (ticket_id, article_sender_type_id, communication_channel_id, is_visible_for_customer, search_index_needs_rebuild, insert_fingerprint, create_time, create_by, change_time, change_by)
                                 VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"""
        cursor.execute(sql2, (ticket_id, article_sender_type_id, communication_channel_id, is_visible_for_customer, search_index_needs_rebuild, insert_fingerprint, current_time, login_name, current_time, login_name))

        article_id = cursor.lastrowid

        incoming_time = generate_timestamp()
        content_path = datetime.now().strftime('%Y/%m/%d')

        cursor.execute('SELECT email, first_name, last_name FROM customer_user WHERE login = %s', (customer_user_name,))
        query_row = cursor.fetchone()
        if not query_row:
            return jsonify({"error": "Customer name or email not found"}), 404
        a_from = query_row[0]

        sql3 = """INSERT INTO article_data_mime (article_id, a_from, a_to, a_subject, a_body, incoming_time, content_path, create_time, create_by, change_time, change_by)
                                         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"""
        cursor.execute(sql3, (article_id, a_from, queue_name, subject, body, incoming_time, content_path, current_time, login_name, current_time, login_name))

        db_connection.commit()

        return jsonify({'message': 'Ticket created successfully'}), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 400
    finally:
        cursor.close()
        db_connection.close()

if __name__ == "__main__":
    app.run(port=5000)
