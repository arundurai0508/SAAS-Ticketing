from flask import Flask, request, jsonify
from datetime import datetime
import re
from services import app
from config.config import DB_Connection
from flasgger import Swagger, swag_from
import hashlib, permission
from services.utils.session_validator import chkValidRequest, chkKeyExistsInHeader

swagger_loc = app.config['SWAGGER_LOC']


def sanitize_name(character):
    return re.sub(r'[+\-*/!#$%^&|<?{}>0123456789]', '', character)


def hash_password_sha256(password):
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    return hashed_password


def has_permission(user_id, required_permission):
    user_permission = permission.get(user_id, {}).get('permission_key', '')
    return required_permission in user_permission or 'admin' in user_permission

@swag_from(swagger_loc + "/AgentUser/create.yml")
@app.route('/api/AgentUser/create', methods=['POST'])
def create_AgentUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                username = data.get('username')
                password = data.get('password')
                first_name = data.get('first_name')
                last_name = data.get('last_name')
                email = data.get('email')
                valid_id = 1
                group_id = 1
                login_user = data.get('login_user')
                permission_key = 'rw'

                current_time = datetime.now()

                if not username or not password or not email or not first_name or not last_name or not valid_id or not login_user :
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_username = sanitize_name(username)
                sanitized_first_name = sanitize_name(first_name)
                sanitized_last_name = sanitize_name(last_name)

                if username != sanitized_username or first_name != sanitized_first_name or last_name != sanitized_last_name:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()
                hashed_password = hash_password_sha256(password)

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query,)
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = """INSERT INTO users (login, pw, first_name, last_name, create_time, create_by, change_time, change_by, valid_id)
                         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s);"""
                cursor.execute(sql, (
                    username, hashed_password, first_name, last_name, current_time, login_name, current_time, login_name, valid_id))

                user_id = cursor.lastrowid

                sql2 = """INSERT INTO user_preferences (user_id, preferences_key, preferences_value)
                          VALUES (%s, %s, %s);"""
                cursor.execute(sql2, (user_id, 'UserEmail', email))

                sql3 ="""INSERT INTO group_user (user_id, group_id, permission_key, create_time, create_by, change_time, change_by)
                          VALUES (%s, %s, %s,%s, %s, %s, %s);"""
                cursor.execute(sql3, (user_id, group_id, permission_key, current_time, login_name, current_time, login_name))

                db_connection.commit()

                return jsonify({'message': 'Agent user created successfully'}), 201

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return {"result": "failure", "data": "invalid api-key"}, 400
    else:
        return {"result": "failure", "data": "api-key missing"}, 400


@swag_from(swagger_loc + "/AgentUser/update.yml")
@app.route('/api/AgentUser/update', methods=['PUT'])
def update_AgentUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                data = request.get_json()
                id = data.get('id')
                username = data.get('username')
                password = data.get('password')
                email = data.get('email')
                first_name = data.get('first_name')
                last_name = data.get('last_name')
                valid_id = data.get('valid_id')
                login_user = data.get('login_user')
                current_time = datetime.now()

                if not username or not password or not email or not first_name or not last_name or not valid_id or not login_user:
                    return jsonify({"error": "All required fields must be provided"}), 400

                sanitized_username = sanitize_name(username)
                sanitized_first_name = sanitize_name(first_name)
                sanitized_last_name = sanitize_name(last_name)

                if username != sanitized_username or first_name != sanitized_first_name or last_name != sanitized_last_name:
                    return jsonify({"error": "Name cannot contain operators"}), 400

                cursor = db_connection.cursor()
                hashed_password = hash_password_sha256(password)

                login_query = (f'SELECT id FROM users where login = "{login_user}";')
                cursor.execute(login_query, )
                login_row = cursor.fetchone()
                if not login_row:
                    return jsonify({"error": "Login Username not found"}), 404
                login_name = login_row[0]

                sql = "SELECT * FROM users WHERE id = ?;"
                cursor.execute(sql, (id,))
                user_data = cursor.fetchone()
                if user_data:

                    valid_query = (f'SELECT id FROM valid where name = "{valid_id}";')
                    cursor.execute(valid_query, )
                    valid = cursor.fetchone()[0]

                    sql = """UPDATE users
                             SET login=%s, pw=%s, first_name=%s, last_name=%s, change_time=%s, change_by=%s, valid_id=%s
                             WHERE id=%s;"""
                    cursor.execute(sql, (
                        username, hashed_password, first_name, last_name, current_time, login_name, valid, id))

                    user_id = id

                    sql2 = """UPDATE user_preferences SET preferences_value=%s WHERE user_id=%s AND preferences_key=%s;"""
                    cursor.execute(sql2, (email, user_id, 'UserEmail'))

                    db_connection.commit()

                    return jsonify({'message': 'Agent user updated successfully'}), 200
                else:
                    return jsonify({'error': 'Agent user not found'}), 404

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/AgentUser/get_all.yml")
@app.route('/api/AgentUser/get_all', methods=['GET'])
def get_all_AgentUser():
    if 'SESSIONKEY' in request.headers:
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                cursor = db_connection.cursor()
                sql_users = "SELECT * FROM users"
                cursor.execute(sql_users)
                user_rows = cursor.fetchall()

                sql_preferences = "SELECT * FROM user_preferences WHERE preferences_key = 'UserEmail'"
                cursor.execute(sql_preferences)
                preferences_rows = cursor.fetchall()

                combined_data = []

                for user_row in user_rows:
                    user_dict = {
                        'User_id': user_row[0],
                        'Username': user_row[1],
                        'Name': f"{user_row[4]} {user_row[5]}",
                        'Email': None
                    }
                    for row in preferences_rows:
                        if row[0] == user_row[0]:
                            user_dict['Email'] = row[2].decode('utf-8') if isinstance(row[2], bytes) else row[2]
                            break
                    combined_data.append(user_dict)

                return jsonify({'data': combined_data}), 200

            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400


@swag_from(swagger_loc + "/AgentUser/get_single.yml")
@app.route('/api/AgentUser/get_single', methods=['GET'])
def get_single_AgentUser():
    if chkKeyExistsInHeader("SESSIONKEY"):
        if chkValidRequest(request.headers["SESSIONKEY"]):
            try:
                db_connection = DB_Connection()
                id = request.args.get('id')
                cursor = db_connection.cursor()

                sql_user = "SELECT * FROM users WHERE id = ?"
                cursor.execute(sql_user, (id,))
                user_row = cursor.fetchone()

                if user_row:
                    user_dict = {
                        'User_id': user_row[0],
                        'Username': user_row[1],
                        'Name': f"{user_row[4]} {user_row[5]}",
                        'Email': None
                    }
                    sql_preference = "SELECT * FROM user_preferences WHERE user_id = ? AND preferences_key = 'UserEmail'"
                    cursor.execute(sql_preference, (id,))
                    preference_row = cursor.fetchone()

                    if preference_row:
                        user_dict['Email'] = preference_row[2].decode('utf-8') if isinstance(preference_row[2], bytes) else preference_row[2]

                    return jsonify({'data': user_dict}), 200
                else:
                    return jsonify({'error': 'User not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 400
            finally:
                db_connection.close()
        else:
            return jsonify({"result": "failure", "data": "invalid api-key"}), 400
    else:
        return jsonify({"result": "failure", "data": "api-key missing"}), 400

