from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flasgger import Swagger

app = Flask(__name__, instance_relative_config=False)
CORS(app)
app.url_map.strict_slashes = False
app.config.from_object('config.config.Config')
db = SQLAlchemy()

app.config['SWAGGER'] = {
    'title': 'Saas-Ticketing',
    'uiversion': 2

}
swagger = Swagger(app)
def create_app():
    """Construct the core application."""
    db.init_app(app)

    with app.app_context():

        from services.routes import userdetails, AgentUser, CustomerID, CustomerUser, Queue, State, Ticket


        db.create_all()
        from services.models import models, defaultdatabasevalue
        return app
