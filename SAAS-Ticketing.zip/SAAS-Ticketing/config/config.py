from datetime import timedelta
import mariadb


class Config():
    SQLALCHEMY_POOL_SIZE = 10
    SQLALCHEMY_MAX_OVERFLOW = 20
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:1234@localhost:5432/Ticketing"
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    BASEURL = "/"
    SECRET="@ut0!ntell!@123"
    EMAIL_VERIFICATION_URL="http://localhost:8985/api"
    RABBITMQIP="app.autointelli.com"
    mq_port=5672
    RABBITMQUSER="autointelli"
    RABBITMQPWD="autointelli"
    RABBITMQVHOST="autointelli"
    MAX_LOGIN_ATTEMPTS=3
    LOCKOUT_DURATION = timedelta(minutes=5)
    SWAGGER_LOC="C:/Users/Autointelli/PycharmProjects/Ticketing/Swagger"
    SMTP_USERNAME="tharwinn1997@gmail.com"
    SMTP_PASSWORD="uwqr bljr bdcv rqgp"


# def DB_Connection():
#     try:
#
#         connection = mariadb.connect(
#             host="demo_file.autointelli.com",
#             port=3306,
#             user="demo_file",
#             password="demo_file",
#             database="demo_file"
#         )
#         return connection
#
#     except mariadb.Error as e:
#         return f"Error connecting to MariaDB Platform: {e}"

def DB_Connection():
    try:

        connection = mariadb.connect(
            host="app.autointelli.com",
            port=10436,
            user="otrs",
            password="otrs123!@#",
            database="otrs"
        )
        return connection

    except mariadb.Error as e:
        return f"Error connecting to MariaDB Platform: {e}"

# class OTRS_URL():
#     url = "http://app.autointelli.com:10480"
#     username = "root@localhost"
#     password = "fdPSRazwDP7wzJed"

class OTRS_URL():
    url = "http://demo_file.autointelli.com:8080"
    username = "root@localhost"
    password = "demo_file"



